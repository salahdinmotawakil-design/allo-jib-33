package ma.allojib.client;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
