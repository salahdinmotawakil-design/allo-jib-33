(function(){
const A=window.AJ,$=(s,r=document)=>r.querySelector(s),live=!!(A.supabaseUrl&&A.supabaseAnonKey);
const wa=t=>"https://wa.me/"+A.whatsapp+"?text="+encodeURIComponent(t);
const H={apikey:A.supabaseAnonKey,"Content-Type":"application/json"};if(String(A.supabaseAnonKey).startsWith("eyJ"))H.Authorization="Bearer "+A.supabaseAnonKey;
async function rest(path){const r=await fetch(A.supabaseUrl+"/rest/v1/"+path,{headers:H});if(!r.ok)throw new Error("rest");return r.json()}
async function rpc(fn,body){const r=await fetch(A.supabaseUrl+"/rest/v1/rpc/"+fn,{method:"POST",headers:H,body:JSON.stringify(body)});const j=await r.json().catch(()=>null);if(!r.ok)throw new Error((j&&j.message)||"rpc");return j}
const ST={NEW:"تم استلام الطلب",PENDING_CONFIRMATION:"في انتظار التأكيد",CONFIRMED:"تم تأكيد الطلب",DRIVER_ASSIGNED:"تعيّن السائق",PICKUP_IN_PROGRESS:"السائق في الطريق للاستلام",PICKED_UP:"تم استلام الطرد",IN_TRANSIT:"في الطريق إليك",DELIVERED:"تم التوصيل",CANCELLED:"تم إلغاء الطلب",FAILED_DELIVERY:"فشل التوصيل",RETURNED:"تم إرجاع الطرد"};
const DST={PENDING:"قيد الانتظار",UNDER_REVIEW:"قيد المراجعة",APPROVED:"مقبول",REJECTED:"مرفوض",CONTACTED:"تم الاتصال بك"};
let Z=[],P=A.demo.pricing;
const hav=(a,b,c,d)=>{const r=Math.PI/180,x=Math.sin((c-a)*r/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin((d-b)*r/2)**2;return 12742*Math.asin(Math.sqrt(x))};
function localQuote(i,j){const a=Z.find(z=>z.id==i),b=Z.find(z=>z.id==j);if(!a||!b)return null;
 const km=Math.round(Math.max(P.min_km,hav(a.lat,a.lng,b.lat,b.lng)*P.road_factor)*10)/10;
 const cost=km*P.deadhead*(P.consumption_l100/100*P.fuel_price+P.maint_per_km)+(km/P.speed_kmh+P.handling_min/60)*P.driver_rate;
 return{km,fee:Math.max(P.min_fee,Math.ceil(cost*(1+P.margin)))}}
async function quote(i,j){if(!i||!j)return null;if(live){try{return await rpc("quote",{z1:i,z2:j})}catch(e){return null}}return localQuote(i,j)}
async function load(){if(live){try{Z=await rest("delivery_zones?active=eq.true&select=id,name,lat,lng&order=name");const s=await rest("pricing_settings?select=*&limit=1");if(s[0]){P=s[0];A.whatsapp=s[0].whatsapp||A.whatsapp}}catch(e){Z=[]}}else Z=A.demo.zones;
 document.querySelectorAll("select[data-zone]").forEach(s=>{s.innerHTML='<option value="">اختر المنطقة</option>'+Z.map(z=>`<option value="${z.id}">${z.name}</option>`).join("")});}
function chrome(){
 $("#hdr").innerHTML=`<div class="bar"><a href="index.html" class="logo" aria-label="ALLO JIB"><img src="assets/logo.png" alt="ALLO JIB — كوموند ديالك توصلك فالحين الحبيب" width="120" height="124"></a>
 <nav aria-label="القائمة"><a href="pricing.html">الأثمنة</a><a href="how.html">كيفاش كتخدم</a><a href="business.html">للمحلات</a><a href="track.html">تتبع الطلب</a><a href="info.html#faq">أسئلة</a></nav><a class="btn" href="order.html">طلب التوصيل</a></div><div class="sp"><div class="wrap"><a href="driver.html">🛵 فضاء السائق</a></div></div>`;
 const here=location.pathname.replace(/^\//,"").replace(/\.html$/,"")||"index";
 const ic=p=>`<svg class="i" viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`,nv=[["index","الرئيسية",ic('<path d="M3 11 12 3l9 8"/><path d="M5 10v10h14V10"/>')],["track","تتبع",ic('<path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/>')],["order","اطلب",ic('<path d="M12 5v14M5 12h14"/>'),1],["pricing","الأثمنة",ic('<path d="M3 12V4h8l10 10-8 8z"/>')],["info","معلومات",ic('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>')]];
 $("#bn").innerHTML=nv.map(([h,l,i,g])=>`<a href="${h=="index"?"index.html":h+".html"}" class="${g?"go ":""}${here==h?"on":""}">${g?`<span class="cr">${i}</span>`:i}<span>${l}</span></a>`).join("");
 $("#ftr").innerHTML=`<div class="fg"><div><img src="assets/logo.png" alt="ALLO JIB" width="110" height="114"><p>من القليعة حتى لباب دارك.</p></div>
 <div><h4>الخدمة</h4><a href="order.html">طلب التوصيل</a><a href="track.html">تتبع الطلب</a><a href="pricing.html">الأثمنة</a><a href="business.html">للمحلات</a></div>
 <div><h4>انضم إلينا</h4><a href="become-driver.html">كن سائق</a><a href="driver.html">فضاء السائق</a><a href="become-driver.html#status">حالة الطلب</a></div>
 <div><h4>معلومات</h4><a href="info.html#about">من نحن</a><a href="info.html#faq">أسئلة شائعة</a><a href="info.html#terms">الشروط</a><a href="info.html#privacy">الخصوصية</a><a href="info.html#delivery">سياسة التوصيل</a></div></div><p class="cp">© ALLO JIB — الدفع نقدا</p>
 <a class="wafab" href="${wa("السلام عليكم ALLO JIB")}" target="_blank" rel="noopener">واتساب</a>`}
const phoneOk=v=>/^(?:\+212|00212|0)[5-7]\d{8}$/.test(v.replace(/[\s.\-]/g,""));
function msg(el,t,ok){el.textContent=t;el.className="msg "+(ok?"ok":"bad")}
function bindQuote(){const a=$("select[name=pickup_zone]"),b=$("select[name=dest_zone]"),o=$("#quote");if(!a||!b||!o)return;
 const go=async()=>{if(!a.value||!b.value){o.innerHTML="اختر منطقة الانطلاق والوجهة باش يبان الثمن.";return}
  const q=await quote(a.value,b.value);o.innerHTML=q?`<span>المسافة التقريبية: <b>${q.km} كلم</b></span><span>ثمن التوصيل: <b class="fee">${q.fee} درهم</b></span>`:"تعذر حساب الثمن، تواصل معنا عبر واتساب.";o.dataset.fee=q?q.fee:"";o.dataset.km=q?q.km:""};
 a.onchange=b.onchange=go;go()}
function zname(id){const z=Z.find(z=>z.id==id);return z?z.name:""}
function forms(){
 const f=$("form[data-form=order]");if(f){
  $("#oth").onchange=e=>{$("#othbox").hidden=!e.target.checked};
  $("#gps").onclick=()=>{const m=$("#gpsm");if(!navigator.geolocation){m.textContent="المتصفح ما كيدعمش تحديد الموقع";return}m.textContent="جاري تحديد موقعك…";navigator.geolocation.getCurrentPosition(p=>{f.dest_lat.value=p.coords.latitude.toFixed(6);f.dest_lng.value=p.coords.longitude.toFixed(6);m.textContent="تم تحديد موقعك ✔ (دقة ~"+Math.round(p.coords.accuracy)+" م)"},()=>{m.textContent="ما قدرناش نحددو موقعك. كتب العنوان بوضوح."},{enableHighAccuracy:true,timeout:15000})};
  try{const p=JSON.parse(localStorage.getItem("aj_prof")||"null");if(p){["customer_name","phone","dest_address"].forEach(k=>{if(p[k])f[k].value=p[k]});if(p.dest_zone&&[...f.dest_zone.options].some(x=>x.value==p.dest_zone)){f.dest_zone.value=p.dest_zone;f.dest_zone.onchange&&f.dest_zone.onchange()}if(p.lat){f.dest_lat.value=p.lat;f.dest_lng.value=p.lng;$("#gpsm").textContent="موقعك المحفوظ ✔"}}}catch(e){}f.onsubmit=async e=>{e.preventDefault();const o=$("#out"),d=Object.fromEntries(new FormData(f));
  if(!$("#oth").checked){d.dest_contact="";d.dest_phone=""}
  if(!d.customer_name||!d.pickup_address||!d.dest_address||!d.item_desc){msg(o,"عمر الاسم، شنو بغيتي، والعنوانين.",0);return}
  if(!phoneOk(d.phone)){msg(o,"رقم الهاتف غير صحيح. مثال: 06 12 34 56 78",0);f.phone.focus();return}
  if(d.pickup_phone&&!phoneOk(d.pickup_phone)){msg(o,"هاتف المحل أو المسؤول غير صحيح.",0);return}
  if($("#oth").checked&&(!d.dest_contact||!phoneOk(d.dest_phone||""))){msg(o,"عمر اسم وهاتف المستلم بشكل صحيح.",0);return}
  if(!$("#quote").dataset.fee){msg(o,"اختر منطقة الانطلاق والوجهة أولا.",0);return}
  const btn=f.querySelector("button[type=submit]");btn.disabled=true;
  let ref="",fee=$("#quote").dataset.fee;
  const text=r=>`السلام عليكم ALLO JIB\n\nبغيت نطلب خدمة التوصيل.\n\nرقم الطلب: ${r||"—"}\nالانطلاق: ${zname(d.pickup_zone)} - ${d.pickup_address}\nالوجهة: ${zname(d.dest_zone)} - ${d.dest_address}\nالثمن: ${fee} درهم\nالطلب: ${d.item_desc}\nالهاتف: ${d.phone}`;
  if(live){try{const r=await rpc("create_order",{p:d});ref=r.ref;fee=r.fee}catch(x){msg(o,"وقع خطأ، تأكد من المعلومات وعاود المحاولة. ("+x.message+")",0);btn.disabled=false;return}
   f.hidden=true;$("#done").hidden=false;$("#ref").textContent=ref;$("#donefee").textContent=fee;$("#dwa").href=wa(text(ref));try{localStorage.setItem("aj_last",JSON.stringify({ref,phone:d.phone}));localStorage.setItem("aj_prof",JSON.stringify({customer_name:d.customer_name,phone:d.phone,dest_address:d.dest_address,dest_zone:d.dest_zone,lat:d.dest_lat,lng:d.dest_lng}))}catch(e){}}
  else{f.hidden=true;$("#done").hidden=false;$("#ref").textContent="غير متوفر (وضع تجريبي)";$("#donefee").textContent=fee;$("#dwa").href=wa(text(""));$("#demo").hidden=false}};}
 const dr=$("form[data-form=driver]");if(dr)dr.onsubmit=async e=>{e.preventDefault();const o=$("#out"),d=Object.fromEntries(new FormData(dr));
  if(!phoneOk(d.phone)){msg(o,"رقم الهاتف غير صحيح.",0);return}if(!d.adult||!d.consent){msg(o,"خاصك تأكد عمرك 18+ وتوافق على سياسة الخصوصية.",0);return}
  d.adult=true;d.consent=true;
  if(!live){msg(o,"الموقع في وضع تجريبي: ما تسجلات الطلب. أرسل معلوماتك عبر واتساب.",0);$("#dwa").hidden=false;$("#dwa").href=wa("السلام عليكم، بغيت نخدم مع ALLO JIB.\nالاسم: "+d.full_name+"\nالهاتف: "+d.phone+"\nالمدينة: "+d.city);return}
  try{const r=await rpc("apply_driver",{p:d});dr.hidden=true;msg($("#out2"),"تسجل طلبك. رقم الطلب: "+r.ref+" — احتفظ به مع رقم هاتفك لمعرفة الحالة.",1)}catch(x){msg(o,"وقع خطأ، عاود المحاولة. ("+x.message+")",0)}};
 const bz=$("form[data-form=business]");if(bz)bz.onsubmit=async e=>{e.preventDefault();const o=$("#out"),d=Object.fromEntries(new FormData(bz));
  if(!phoneOk(d.phone)){msg(o,"رقم الهاتف غير صحيح.",0);return}
  if(!live){location.href=wa("السلام عليكم ALLO JIB، بغيت نتعاون معاكم.\nالمحل: "+d.business_name+"\nالمسؤول: "+d.owner_name+"\nالهاتف: "+d.phone+"\nالنوع: "+d.business_type);return}
  try{await rpc("create_business_request",{p:d});bz.hidden=true;msg($("#out2"),"توصلنا بطلبك وغادي نتواصلو معاك.",1)}catch(x){msg(o,"وقع خطأ، عاود المحاولة.",0)}};
 const tr=$("form[data-form=track]");if(tr){let timer=0,map=null,mk={};
  const FIN=["DELIVERED","CANCELLED","FAILED_DELIVERY","RETURNED"],PR=["CONFIRMED","DRIVER_ASSIGNED","PICKUP_IN_PROGRESS","PICKED_UP","IN_TRANSIT","DELIVERED"];
  try{const l=JSON.parse(localStorage.getItem("aj_last")||"null");if(l){tr.ref.value=l.ref;tr.phone.value=l.phone}}catch(e){}
  const pin=(e,c)=>L.divIcon({html:`<div class="pin" style="${c||""}">${e}</div>`,className:"",iconSize:[34,34],iconAnchor:[17,17]});
  function draw(r){const o=$("#out");const i=PR.indexOf(r.status);const hasD=r.driver_lat!=null;
   let km="";if(hasD&&r.dest_lat!=null)km=` · يبعد عنك ~${hav(r.driver_lat,r.driver_lng,r.dest_lat,r.dest_lng).toFixed(1)} كلم`;
   o.className="msg ok";o.innerHTML=`<b>${r.ref}</b> — ${ST[r.status]||r.status}<div class="prog">${PR.map((p,k)=>`<span class="${k<=i?"on":""}">${ST[p]}</span>`).join("")}</div>من ${r.pickup||""} إلى ${r.dest||""} · ${r.fee} درهم${r.driver_name?`<br>السائق: <b>${r.driver_name}</b>${km}`:""}<br><small>آخر تحديث: ${new Date(r.updated_at).toLocaleString("ar-MA")}</small>${hasD?'<div class="map" id="map"></div>':(["PICKUP_IN_PROGRESS","PICKED_UP","IN_TRANSIT"].includes(r.status)?'<p class="note">كنتسناو موقع السائق…</p>':"")}`;
   if(hasD){if(typeof L==="undefined"){$("#map").outerHTML='<p class="note">تعذر تحميل الخريطة.</p>';return}
    map=L.map("map",{zoomControl:true}).setView([r.driver_lat,r.driver_lng],14);L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap"}).addTo(map);
    mk.d=L.marker([r.driver_lat,r.driver_lng],{icon:pin("🛵")}).addTo(map);const pts=[[r.driver_lat,r.driver_lng]];
    if(r.dest_lat!=null){mk.t=L.marker([r.dest_lat,r.dest_lng],{icon:pin("📍","background:#1f9d55;color:#fff")}).addTo(map);pts.push([r.dest_lat,r.dest_lng])}
    if(pts.length>1)map.fitBounds(pts,{padding:[40,40]})}else{map=null}}
  async function poll(first){const d=Object.fromEntries(new FormData(tr));try{const r=await rpc("track_order",{p_ref:d.ref,p_phone:d.phone});if(!r){clearInterval(timer);msg($("#out"),"ما لقينا طلب بهاد الرقم والهاتف.",0);return}
   if(first||!map||r.driver_lat==null||!$("#map")){draw(r)}else{mk.d.setLatLng([r.driver_lat,r.driver_lng]);const sp=$("#out b");$("#out").querySelector("small").textContent="آخر تحديث: "+new Date(r.updated_at).toLocaleString("ar-MA")}
   if(FIN.includes(r.status))clearInterval(timer)}catch(x){msg($("#out"),"وقع خطأ، عاود المحاولة.",0)}}
  tr.onsubmit=async e=>{e.preventDefault();clearInterval(timer);if(!live){const o=$("#out");o.className="msg bad";o.textContent="التتبع الآلي غير مفعل بعد. اطلب الحالة عبر واتساب.";return}await poll(true);timer=setInterval(()=>poll(false),8000)}}
 const ds=$("form[data-form=dstatus]");if(ds)ds.onsubmit=async e=>{e.preventDefault();const o=$("#sout"),d=Object.fromEntries(new FormData(ds));
  if(!live){msg(o,"غير مفعل في الوضع التجريبي.",0);return}
  try{const r=await rpc("driver_status",{p_ref:d.ref,p_phone:d.phone});r?msg(o,"حالة طلبك: "+(DST[r.status]||r.status),1):msg(o,"ما لقينا طلب بهاد المعلومات.",0)}catch(x){msg(o,"وقع خطأ.",0)}};
}
document.addEventListener("DOMContentLoaded",async()=>{chrome();document.body.classList.add("site");const io="IntersectionObserver"in window?new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}}),{threshold:.12}):null;document.querySelectorAll(".rv").forEach(e=>io?io.observe(e):e.classList.add("in"));await load();bindQuote();forms();
 const pt=$("#ptable");if(pt&&Z.length){const rows=[];for(const z of Z){if(z.id==Z[0].id)continue;const q=await quote(Z[0].id,z.id);if(q)rows.push(`<tr><td>${Z[0].name} ← ${z.name}</td><td>${q.km} كلم</td><td><b>${q.fee} درهم</b></td></tr>`)}pt.innerHTML=rows.join("")}});
})();
