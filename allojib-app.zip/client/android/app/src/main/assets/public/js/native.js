/* Pont natif (Capacitor). Sur le web : ne fait rien. Dans l'app Android/iOS : OAuth système, push, GPS arrière-plan. */
(function(){
 const C=window.Capacitor,native=!!(C&&C.isNativePlatform&&C.isNativePlatform());
 window.NATIVE={on:native,platform:native?C.getPlatform():"web"};
 if(!native)return;
 document.documentElement.classList.add("native");
 const reg=n=>C.registerPlugin(n);
 // Google interdit l'OAuth dans une WebView : on ouvre le navigateur système puis on revient par lien profond
 NATIVE.oauth=(url,scheme,cb)=>{const App=reg("App"),Browser=reg("Browser");App.addListener("appUrlOpen",e=>{if(e.url&&e.url.startsWith(scheme)){Browser.close().catch(()=>{});cb((e.url.split("#")[1])||"")}});Browser.open({url})};
 NATIVE.registerPush=async cb=>{try{const P=reg("PushNotifications");let s=await P.checkPermissions();if(s.receive!=="granted")s=await P.requestPermissions();if(s.receive!=="granted")return;P.addListener("registration",t=>cb(t.value));await P.register()}catch(e){}};
 let wid=null;
 NATIVE.startGeo=async cb=>{if(wid!==null)return;const BG=reg("BackgroundGeolocation");wid=await BG.addWatcher({backgroundMessage:"موقعك كيتشارك مع الزبون حتى يتسلم الطلب.",backgroundTitle:"ALLO JIB",requestPermissions:true,stale:false,distanceFilter:15},(loc,err)=>{if(err){if(err.code==="NOT_AUTHORIZED"&&confirm("خاص الإذن ديال الموقع. تحل الإعدادات؟"))BG.openSettings();return}cb(loc)})};
 NATIVE.stopGeo=async()=>{if(wid===null)return;const BG=reg("BackgroundGeolocation");const id=wid;wid=null;await BG.removeWatcher({id})};
})();
