/* ===== CONFIG ALLO JIB ===== */
window.AJ = {
  supabaseUrl: "https://dlfdvfqlduyfclzpxifk.supabase.co",
  supabaseAnonKey: "sb_publishable_WEf6nTc-vVuaa11M65-XCA_ogHVHDqt", // clé publishable (jamais la clé secrète)
  whatsapp: "212630451217", // À VÉRIFIER / remplacer par le numéro ALLO JIB
  // Mode démo (Supabase vide) : mêmes formules que schema.sql, commandes envoyées par WhatsApp seulement.
  demo: {
    pricing:{fuel_price:18,consumption_l100:2.5,maint_per_km:.3,deadhead:1.5,driver_rate:20,speed_kmh:25,handling_min:10,margin:.3,min_fee:10,road_factor:1.3,min_km:2},
    zones:[ // coordonnées approximatives, à vérifier
      {id:"القليعة",name:"القليعة",lat:30.29,lng:-9.47},{id:"أيت ملول",name:"أيت ملول",lat:30.3344,lng:-9.4972},
      {id:"إنزكان",name:"إنزكان",lat:30.3553,lng:-9.5361},{id:"الدشيرة",name:"الدشيرة",lat:30.3813,lng:-9.5436},{id:"أكادير",name:"أكادير",lat:30.4278,lng:-9.5981}]
  }
};
