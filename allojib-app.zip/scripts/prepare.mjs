// Usage (depuis client/ ou driver/) : node ../scripts/prepare.mjs client|driver
import fs from 'node:fs'; import path from 'node:path';
const app = process.argv[2]; if (!['client','driver'].includes(app)) { console.error('client|driver'); process.exit(1); }
const src = path.resolve('..', 'web'), out = path.resolve('www');
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
const skip = new Set(['supabase','apps-script','README.txt','admin.html','robots.txt','manifest.webmanifest','driver.webmanifest']);
if (app === 'client') skip.add('driver.html');
function copy(from, to, top) {
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    if (top && skip.has(e.name)) continue;
    if (e.name.endsWith('.zip')) continue;
    const a = path.join(from, e.name), b = path.join(to, e.name);
    if (e.isDirectory()) { fs.mkdirSync(b, { recursive: true }); copy(a, b, false); } else fs.copyFileSync(a, b);
  }
}
if (app === 'client') copy(src, out, true);
else { // l'app livreur ouvre directement l'espace livreur
  for (const d of ['css','js','assets']) { fs.mkdirSync(path.join(out,d), { recursive: true }); copy(path.join(src,d), path.join(out,d), false); }
  fs.copyFileSync(path.join(src,'driver.html'), path.join(out,'index.html'));
}
console.log('www prêt pour', app);
