# ALLO JIB — applications Android (client + livreur)

Deux applications construites avec Capacitor à partir du même site (dossier `web/`) et de la même base Supabase :
- `client/` : application client (ma.allojib.client)
- `driver/` : application livreur (ma.allojib.driver) avec GPS en arrière-plan, notifications push et connexion Google par navigateur système.

## 1. Obtenir les APK sans Android Studio (GitHub)
1. Créez un compte sur github.com, puis un nouveau dépôt (privé).
2. Envoyez-y TOUT le contenu de ce dossier (y compris le dossier caché `.github`).
3. Onglet **Actions** > **Build Android APK** > **Run workflow**.
4. Quand c'est vert, ouvrez l'exécution > **Artifacts** : `allojib-client-apk` et `allojib-driver-apk`.
5. Installez le fichier .apk sur un téléphone Android (autoriser « sources inconnues »).

## 2. À faire dans Supabase
- Authentication > URL Configuration > Redirect URLs : ajouter `ma.allojib.driver://login`
- SQL Editor : exécuter `web/supabase/010_push.sql` (ou le all-in-one).

## 3. Notifications push (livreur)
1. console.firebase.google.com : créer un projet, ajouter une app Android avec l'ID `ma.allojib.driver`, télécharger `google-services.json`, le placer dans `driver/android/app/`.
2. Firebase > Paramètres > Comptes de service > générer une clé privée (JSON).
3. Supabase > Edge Functions : créer `send-push` avec le code de `web/supabase/functions/send-push/index.ts` ; Secrets : `FCM_SERVICE_ACCOUNT` (contenu du JSON), `WEBHOOK_SECRET` (mot de passe au choix).
4. Supabase > Database > Webhooks : table `notifications`, évènement INSERT, appel de la fonction, en-tête `x-webhook-secret` = WEBHOOK_SECRET.
5. Relancer la compilation GitHub.

## 4. Après les tests
- Google Play : compte développeur (paiement unique) + application signée (AAB) : étape suivante.
- iPhone : compte Apple Developer (annuel) + un Mac ou un runner macOS : `npx cap add ios`.

## 5. Limites actuelles (à connaître)
- Rien n'a été compilé ni testé sur un téléphone par l'auteur de ces fichiers : les premiers essais peuvent révéler des ajustements.
- Push livreur uniquement ; pas de push côté client (le suivi se fait dans l'app).
- Fonctionne avec les APK « debug » (installation directe), pas encore publiable sur Google Play.
