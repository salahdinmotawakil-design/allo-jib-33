-- ALLO JIB — étape 7 : « à la demande » + GPS livreur en direct (pendant une livraison active uniquement)
alter table delivery_orders add column if not exists dest_lat numeric, add column if not exists dest_lng numeric;

create table if not exists driver_locations(
  driver_id uuid primary key references driver_profiles(user_id) on delete cascade,
  lat numeric not null, lng numeric not null, accuracy numeric, updated_at timestamptz not null default now());
alter table driver_locations enable row level security;
drop policy if exists loc_admin on driver_locations; create policy loc_admin on driver_locations for select using (is_admin());
grant select on driver_locations to authenticated; revoke all on driver_locations from anon;

create or replace function create_order(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare km numeric; f numeric; r text; oid uuid; dc text; dph text; dlat numeric; dlng numeric;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 dc := coalesce(nullif(trim(p->>'dest_contact'),''),p->>'customer_name'); dph := coalesce(nullif(trim(p->>'dest_phone'),''),p->>'phone');
 if not valid_ma_phone(dph) then raise exception 'phone destinataire invalide'; end if;
 if nullif(trim(p->>'pickup_phone'),'') is not null and not valid_ma_phone(p->>'pickup_phone') then raise exception 'phone enlevement invalide'; end if;
 dlat := nullif(p->>'dest_lat','')::numeric; dlng := nullif(p->>'dest_lng','')::numeric;
 if dlat is not null and (dlat not between 20 and 37 or dlng is null or dlng not between -18 and 0) then dlat := null; dlng := null; end if;
 if length(coalesce(p->>'customer_name',''))<2 or length(coalesce(p->>'pickup_address',''))<3 or length(coalesce(p->>'dest_address',''))<3 then raise exception 'champs requis'; end if;
 km := route_km((p->>'pickup_zone')::uuid,(p->>'dest_zone')::uuid); f := calc_fee(km);
 r := 'AJ-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into delivery_orders(ref,customer_name,phone,whatsapp,pickup_zone,pickup_address,pickup_contact,pickup_phone,pickup_link,dest_zone,dest_address,dest_contact,dest_phone,pkg_type,item_desc,pkg_size,notes,distance_km,fee,dest_lat,dest_lng)
 values(r,left(p->>'customer_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),(p->>'pickup_zone')::uuid,left(p->>'pickup_address',300),left(p->>'pickup_contact',120),left(p->>'pickup_phone',30),left(p->>'pickup_link',500),(p->>'dest_zone')::uuid,left(p->>'dest_address',300),left(dc,120),left(regexp_replace(dph,'[\s.\-]','','g'),30),left(p->>'pkg_type',60),left(p->>'item_desc',500),left(p->>'pkg_size',30),left(p->>'notes',500),km,f,dlat,dlng) returning id into oid;
 insert into order_status_history(order_id,status) select id,status from delivery_orders where id=oid;
 perform dispatch_pending();
 return jsonb_build_object('ref',r,'km',km,'fee',f);
end $$;


create or replace function driver_orders() returns jsonb language plpgsql volatile security definer set search_path=public as $$
declare s pricing_settings; r jsonb;
begin
 perform dispatch_pending();
 select * into s from pricing_settings where id=1;
 select coalesce(jsonb_agg(x order by (x->>'created_at') desc),'[]'::jsonb) into r from (
  select jsonb_build_object('id',o.id,'ref',o.ref,'status',o.status,'created_at',o.created_at,'updated_at',o.updated_at,
   'accepted',(o.accepted_at is not null or o.status<>'DRIVER_ASSIGNED'),
   'offer_left',case when o.status='DRIVER_ASSIGNED' and o.accepted_at is null and o.offered_at is not null then greatest(0,floor(s.offer_timeout_min*60-extract(epoch from now()-o.offered_at))) else null end,
   'pickup_zone',a.name,'dest_zone',b.name,'fee',o.fee,'km',o.distance_km,'item_desc',o.item_desc,'pkg_size',o.pkg_size,
   'pickup_address',case when v then o.pickup_address end,'pickup_contact',case when v then o.pickup_contact end,'pickup_phone',case when v then nullif(o.pickup_phone,'') end,'pickup_link',case when v then o.pickup_link end,
   'dest_address',case when v then o.dest_address end,'dest_contact',case when v then o.dest_contact end,'dest_phone',case when v then o.dest_phone end,'notes',case when v then o.notes end,'dest_lat',case when v then o.dest_lat end,'dest_lng',case when v then o.dest_lng end,
   'customer_name',case when v then o.customer_name end,'customer_phone',case when v then o.phone end) x
  from (select oo.*, not (oo.status='DRIVER_ASSIGNED' and oo.accepted_at is null) as v from delivery_orders oo) o
  left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
  where o.driver_id=auth.uid() and exists(select 1 from driver_profiles where user_id=auth.uid() and active)
  order by o.created_at desc limit 100) s2;
 return r;
end $$;


create or replace function driver_update_location(p_lat numeric,p_lng numeric,p_acc numeric default null) returns void language plpgsql security definer set search_path=public as $$
begin
 if p_lat not between -90 and 90 or p_lng not between -180 and 180 then raise exception 'coordonnées invalides'; end if;
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 if not exists(select 1 from delivery_orders where driver_id=auth.uid() and status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT')) then
  delete from driver_locations where driver_id=auth.uid(); return;
 end if;
 insert into driver_locations(driver_id,lat,lng,accuracy,updated_at) values(auth.uid(),p_lat,p_lng,p_acc,now())
 on conflict(driver_id) do update set lat=excluded.lat,lng=excluded.lng,accuracy=excluded.accuracy,updated_at=now();
end $$;
revoke execute on function driver_update_location(numeric,numeric,numeric) from public, anon;
grant execute on function driver_update_location(numeric,numeric,numeric) to authenticated;

-- La position est supprimée dès qu'il n'y a plus de livraison active
create or replace function cleanup_driver_location() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.driver_id is not null and new.status in('DELIVERED','FAILED_DELIVERY','CANCELLED','RETURNED')
    and not exists(select 1 from delivery_orders where driver_id=new.driver_id and status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT')) then
  delete from driver_locations where driver_id=new.driver_id;
 end if;
 return new;
end $$;
drop trigger if exists trg_cleanup_loc on delivery_orders;
create trigger trg_cleanup_loc after update of status on delivery_orders for each row execute function cleanup_driver_location();

-- Suivi client : position du livreur seulement pendant la livraison et si fraîche (< 3 min)
create or replace function track_order(p_ref text,p_phone text) returns jsonb language sql stable security definer set search_path=public as $$
 select jsonb_build_object('ref',o.ref,'status',o.status,'pickup',a.name,'dest',b.name,'fee',o.fee,'updated_at',o.updated_at,
  'dest_lat',o.dest_lat,'dest_lng',o.dest_lng,
  'driver_name',case when o.driver_id is not null and o.status in('DRIVER_ASSIGNED','PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT') then split_part(coalesce(dp.full_name,''),' ',1) end,
  'driver_lat',case when o.status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT') and l.updated_at>now()-interval '3 minutes' then l.lat end,
  'driver_lng',case when o.status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT') and l.updated_at>now()-interval '3 minutes' then l.lng end,
  'driver_at',case when o.status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT') and l.updated_at>now()-interval '3 minutes' then l.updated_at end)
 from delivery_orders o left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
 left join driver_profiles dp on dp.user_id=o.driver_id left join driver_locations l on l.driver_id=o.driver_id
 where o.ref=upper(trim(p_ref)) and o.phone=regexp_replace(p_phone,'[\s.\-]','','g') $$;
