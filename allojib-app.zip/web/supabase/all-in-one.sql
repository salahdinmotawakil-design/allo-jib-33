-- ALLO JIB : installation complète. Idempotent : peut être exécuté plusieurs fois, sur projet neuf ou existant.

-- ===== schema.sql =====
-- ALLO JIB — schéma Supabase (étape 1). Exécuter dans SQL Editor.
create extension if not exists pgcrypto;

create table if not exists pricing_settings(
  id int primary key default 1 check(id=1),
  fuel_price numeric not null default 18,        -- DH/litre (essence)
  consumption_l100 numeric not null default 2.5, -- L/100 km (hypothèse scooter, à vérifier)
  maint_per_km numeric not null default 0.30,    -- usure/huile/pneus DH/km (hypothèse)
  deadhead numeric not null default 1.5,         -- facteur retour à vide
  driver_rate numeric not null default 20,       -- DH/heure livreur incl. fatigue (hypothèse)
  speed_kmh numeric not null default 25,
  handling_min numeric not null default 10,      -- minutes collecte + remise
  margin numeric not null default 0.30,          -- marge plateforme
  min_fee numeric not null default 10,
  road_factor numeric not null default 1.3,      -- route ≈ ligne droite x 1.3
  min_km numeric not null default 2,
  whatsapp text not null default '212630451217'
);
insert into pricing_settings(id) values(1) on conflict do nothing;

create table if not exists delivery_zones(
  id uuid primary key default gen_random_uuid(),
  name text not null unique, lat numeric not null, lng numeric not null,
  note text, active boolean not null default true, created_at timestamptz default now());
-- Coordonnées APPROXIMATIVES : vérifiez et corrigez depuis Google Maps.
insert into delivery_zones(name,lat,lng,note) values
 ('القليعة',30.2900,-9.4700,'Point de départ — à vérifier'),
 ('أيت ملول',30.3344,-9.4972,'à vérifier'),
 ('إنزكان',30.3553,-9.5361,'à vérifier'),
 ('الدشيرة',30.3813,-9.5436,'à vérifier'),
 ('أكادير',30.4278,-9.5981,'à vérifier') on conflict do nothing;

create table if not exists delivery_orders(
  id uuid primary key default gen_random_uuid(), ref text unique not null,
  customer_name text not null, phone text not null, whatsapp text,
  pickup_zone uuid references delivery_zones(id), pickup_address text not null, pickup_contact text, pickup_phone text, pickup_link text,
  dest_zone uuid references delivery_zones(id), dest_address text not null, dest_contact text, dest_phone text,
  pkg_type text, item_desc text, pkg_size text, notes text,
  distance_km numeric, fee numeric, payment text default 'cash',
  status text not null default 'PENDING_CONFIRMATION' check(status in('NEW','PENDING_CONFIRMATION','CONFIRMED','DRIVER_ASSIGNED','PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT','DELIVERED','CANCELLED','FAILED_DELIVERY','RETURNED')),
  internal_notes text, created_at timestamptz default now(), updated_at timestamptz default now());
create index if not exists orders_phone on delivery_orders(phone);
create index if not exists orders_status on delivery_orders(status,created_at desc);

create table if not exists order_status_history(
  id bigserial primary key, order_id uuid references delivery_orders(id) on delete cascade,
  status text not null, changed_by uuid, created_at timestamptz default now());

create table if not exists driver_applications(
  id uuid primary key default gen_random_uuid(), ref text unique not null,
  full_name text not null, phone text not null, whatsapp text, city text, address text,
  has_moto boolean, moto_type text, has_licence boolean, has_docs boolean, experience text, hours text, areas text,
  consent boolean not null default false,
  status text not null default 'PENDING' check(status in('PENDING','UNDER_REVIEW','APPROVED','REJECTED','CONTACTED')),
  admin_notes text, created_at timestamptz default now());

create table if not exists business_requests(
  id uuid primary key default gen_random_uuid(), business_name text not null, owner_name text, phone text not null,
  address text, business_type text, volume text, message text, status text default 'NEW', created_at timestamptz default now());

create table if not exists admins(user_id uuid primary key references auth.users(id) on delete cascade);

-- ===== Calcul du prix (SEULE source de vérité : le serveur) =====
create or replace function haversine_km(a1 numeric,o1 numeric,a2 numeric,o2 numeric) returns numeric language sql immutable as $$
 select (6371*2*asin(sqrt(power(sin(radians(a2-a1)/2),2)+cos(radians(a1))*cos(radians(a2))*power(sin(radians(o2-o1)/2),2))))::numeric $$;

create or replace function calc_fee(km numeric) returns numeric language plpgsql stable as $$
declare s pricing_settings; eff numeric; cost numeric;
begin select * into s from pricing_settings where id=1;
 eff := km*s.deadhead;
 cost := eff*(s.consumption_l100/100*s.fuel_price + s.maint_per_km) + (km/s.speed_kmh + s.handling_min/60)*s.driver_rate;
 return greatest(s.min_fee, ceil(cost*(1+s.margin)));
end $$;

create or replace function route_km(z1 uuid,z2 uuid) returns numeric language plpgsql stable security definer set search_path=public as $$
declare a delivery_zones; b delivery_zones; s pricing_settings;
begin select * into a from delivery_zones where id=z1 and active; select * into b from delivery_zones where id=z2 and active; select * into s from pricing_settings where id=1;
 if a.id is null or b.id is null then raise exception 'zone invalide'; end if;
 return round(greatest(s.min_km, haversine_km(a.lat,a.lng,b.lat,b.lng)*s.road_factor),1);
end $$;

create or replace function valid_ma_phone(p text) returns boolean language sql immutable as $$
 select regexp_replace(coalesce(p,''),'[\s.\-]','','g') ~ '^(\+212|00212|0)[5-7][0-9]{8}$' $$;

create or replace function create_order(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare km numeric; f numeric; r text; oid uuid;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 if length(coalesce(p->>'customer_name',''))<2 or length(coalesce(p->>'pickup_address',''))<3 or length(coalesce(p->>'dest_address',''))<3 then raise exception 'champs requis'; end if;
 km := route_km((p->>'pickup_zone')::uuid,(p->>'dest_zone')::uuid); f := calc_fee(km);
 r := 'AJ-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into delivery_orders(ref,customer_name,phone,whatsapp,pickup_zone,pickup_address,pickup_contact,pickup_phone,pickup_link,dest_zone,dest_address,dest_contact,dest_phone,pkg_type,item_desc,pkg_size,notes,distance_km,fee)
 values(r,left(p->>'customer_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),(p->>'pickup_zone')::uuid,left(p->>'pickup_address',300),left(p->>'pickup_contact',120),left(p->>'pickup_phone',30),left(p->>'pickup_link',500),(p->>'dest_zone')::uuid,left(p->>'dest_address',300),left(p->>'dest_contact',120),left(p->>'dest_phone',30),left(p->>'pkg_type',60),left(p->>'item_desc',500),left(p->>'pkg_size',30),left(p->>'notes',500),km,f) returning id into oid;
 insert into order_status_history(order_id,status) values(oid,'PENDING_CONFIRMATION');
 return jsonb_build_object('ref',r,'km',km,'fee',f);
end $$;

create or replace function quote(z1 uuid,z2 uuid) returns jsonb language sql stable security definer set search_path=public as $$
 select jsonb_build_object('km',route_km(z1,z2),'fee',calc_fee(route_km(z1,z2))) $$;

create or replace function track_order(p_ref text,p_phone text) returns jsonb language sql stable security definer set search_path=public as $$
 select jsonb_build_object('ref',o.ref,'status',o.status,'pickup',a.name,'dest',b.name,'fee',o.fee,'updated_at',o.updated_at)
 from delivery_orders o left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
 where o.ref=upper(trim(p_ref)) and o.phone=regexp_replace(p_phone,'[\s.\-]','','g') $$;

create or replace function apply_driver(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare r text;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 if coalesce((p->>'consent')::boolean,false)=false or coalesce((p->>'adult')::boolean,false)=false then raise exception 'consentement requis'; end if;
 r:='DR-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into driver_applications(ref,full_name,phone,whatsapp,city,address,has_moto,moto_type,has_licence,has_docs,experience,hours,areas,consent)
 values(r,left(p->>'full_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),left(p->>'city',80),left(p->>'address',300),(p->>'has_moto')='yes',left(p->>'moto_type',80),(p->>'has_licence')='yes',(p->>'has_docs')='yes',left(p->>'experience',500),left(p->>'hours',200),left(p->>'areas',300),true);
 return jsonb_build_object('ref',r);
end $$;

create or replace function driver_status(p_ref text,p_phone text) returns jsonb language sql stable security definer set search_path=public as $$
 select jsonb_build_object('ref',ref,'status',status) from driver_applications where ref=upper(trim(p_ref)) and phone=regexp_replace(p_phone,'[\s.\-]','','g') $$;

create or replace function create_business_request(p jsonb) returns void language plpgsql security definer set search_path=public as $$
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 insert into business_requests(business_name,owner_name,phone,address,business_type,volume,message)
 values(left(p->>'business_name',150),left(p->>'owner_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'address',300),left(p->>'business_type',80),left(p->>'volume',80),left(p->>'message',800));
end $$;

-- ===== Sécurité (RLS) =====
alter table pricing_settings enable row level security; alter table delivery_zones enable row level security;
alter table delivery_orders enable row level security; alter table order_status_history enable row level security;
alter table driver_applications enable row level security; alter table business_requests enable row level security; alter table admins enable row level security;

create or replace function is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from admins where user_id=auth.uid()) $$;

drop policy if exists zones_read on delivery_zones; create policy zones_read on delivery_zones for select using (active or is_admin());
drop policy if exists zones_admin on delivery_zones; create policy zones_admin on delivery_zones for all using (is_admin()) with check (is_admin());
drop policy if exists settings_read on pricing_settings; create policy settings_read on pricing_settings for select using (true);
drop policy if exists settings_admin on pricing_settings; create policy settings_admin on pricing_settings for all using (is_admin()) with check (is_admin());
drop policy if exists orders_admin on delivery_orders; create policy orders_admin on delivery_orders for all using (is_admin()) with check (is_admin());
drop policy if exists hist_admin on order_status_history; create policy hist_admin on order_status_history for all using (is_admin()) with check (is_admin());
drop policy if exists drivers_admin on driver_applications; create policy drivers_admin on driver_applications for all using (is_admin()) with check (is_admin());
drop policy if exists biz_admin on business_requests; create policy biz_admin on business_requests for all using (is_admin()) with check (is_admin());
-- Ajoutez votre compte admin : insert into admins values('<uuid de votre utilisateur Auth>');

revoke execute on function create_order(jsonb),apply_driver(jsonb),create_business_request(jsonb),quote(uuid,uuid),track_order(text,text),driver_status(text,text) from public;
grant execute on function create_order(jsonb),quote(uuid,uuid),track_order(text,text),apply_driver(jsonb),driver_status(text,text),create_business_request(jsonb) to anon,authenticated;

-- ===== 002_admin.sql =====
-- ALLO JIB — étape 2 : historique automatique des statuts
create or replace function on_order_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
  new.updated_at := now();
  if new.status is distinct from old.status then
    insert into order_status_history(order_id,status,changed_by) values(new.id,new.status,auth.uid());
  end if;
  return new;
end $$;
drop trigger if exists trg_order_update on delivery_orders;
create trigger trg_order_update before update on delivery_orders for each row execute function on_order_update();

-- Un admin peut lire sa propre ligne (sert à vérifier l'accès au login)
drop policy if exists admins_self on admins;
drop policy if exists admins_self on admins; create policy admins_self on admins for select using (user_id = auth.uid());

-- ===== 003_grants.sql =====
-- ALLO JIB : accès API (les nouveaux projets Supabase n'exposent plus les tables automatiquement)
grant usage on schema public to anon, authenticated;
grant select on delivery_zones, pricing_settings to anon, authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant usage, select on all sequences in schema public to authenticated;
revoke all on delivery_orders, order_status_history, driver_applications, business_requests, admins from anon;
-- La sécurité réelle reste assurée par les policies RLS (réservées à l'admin).

-- ===== 004_driver.sql =====
-- ALLO JIB — étape 3 : espace livreur
create table if not exists driver_profiles(
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null, phone text, active boolean not null default true, online boolean not null default false,
  created_at timestamptz default now());
alter table delivery_orders add column if not exists driver_id uuid references driver_profiles(user_id);
create index if not exists orders_driver on delivery_orders(driver_id,status);

create table if not exists delivery_proofs(
  id bigserial primary key, order_id uuid references delivery_orders(id) on delete cascade,
  driver_id uuid, recipient_name text, created_at timestamptz default now());

alter table driver_profiles enable row level security; alter table delivery_proofs enable row level security;
drop policy if exists dp_admin on driver_profiles; create policy dp_admin on driver_profiles for all using (is_admin()) with check (is_admin());
drop policy if exists dp_self on driver_profiles; create policy dp_self on driver_profiles for select using (user_id=auth.uid());
drop policy if exists proof_admin on delivery_proofs; create policy proof_admin on delivery_proofs for all using (is_admin()) with check (is_admin());

grant select,insert,update,delete on driver_profiles, delivery_proofs to authenticated;
grant usage,select on all sequences in schema public to authenticated;
revoke all on driver_profiles, delivery_proofs from anon;

-- Admin : lier un compte Auth existant à un livreur (jamais d'auto-approbation)
create or replace function admin_add_driver(p_email text,p_name text,p_phone text) returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid;
begin
 if not is_admin() then raise exception 'interdit'; end if;
 select id into uid from auth.users where lower(email)=lower(trim(p_email));
 if uid is null then raise exception 'compte introuvable : créez-le dans Authentication > Users'; end if;
 insert into driver_profiles(user_id,full_name,phone) values(uid,left(p_name,120),left(p_phone,30))
 on conflict(user_id) do update set full_name=excluded.full_name, phone=excluded.phone, active=true;
 return jsonb_build_object('user_id',uid);
end $$;

create or replace function driver_me() returns jsonb language sql stable security definer set search_path=public as $$
 select to_jsonb(d) - 'created_at' from driver_profiles d where user_id=auth.uid() and active $$;

create or replace function driver_set_online(b boolean) returns void language plpgsql security definer set search_path=public as $$
begin update driver_profiles set online=b where user_id=auth.uid() and active; end $$;

-- Le livreur ne voit que SES commandes et seulement les champs nécessaires
create or replace function driver_orders() returns jsonb language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(x order by (x->>'created_at') desc),'[]'::jsonb) from (
  select jsonb_build_object('id',o.id,'ref',o.ref,'status',o.status,'created_at',o.created_at,'updated_at',o.updated_at,
   'pickup_zone',a.name,'pickup_address',o.pickup_address,'pickup_contact',o.pickup_contact,'pickup_phone',coalesce(nullif(o.pickup_phone,''),o.phone),'pickup_link',o.pickup_link,
   'dest_zone',b.name,'dest_address',o.dest_address,'dest_contact',o.dest_contact,'dest_phone',o.dest_phone,
   'item_desc',o.item_desc,'pkg_size',o.pkg_size,'notes',o.notes,'fee',o.fee) x
  from delivery_orders o left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
  where o.driver_id=auth.uid() and exists(select 1 from driver_profiles where user_id=auth.uid() and active)
  order by o.created_at desc limit 100) s $$;

-- Workflow sécurisé : seules ces transitions sont permises au livreur
create or replace function driver_update_status(p_id uuid,p_status text,p_recipient text default null) returns void language plpgsql security definer set search_path=public as $$
declare cur text; ok boolean;
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 select status into cur from delivery_orders where id=p_id and driver_id=auth.uid();
 if cur is null then raise exception 'commande introuvable'; end if;
 ok := (cur='DRIVER_ASSIGNED' and p_status='PICKUP_IN_PROGRESS') or (cur='PICKUP_IN_PROGRESS' and p_status='PICKED_UP')
    or (cur='PICKED_UP' and p_status='IN_TRANSIT') or (cur='IN_TRANSIT' and p_status in('DELIVERED','FAILED_DELIVERY'))
    or (cur='PICKED_UP' and p_status='FAILED_DELIVERY');
 if not ok then raise exception 'transition interdite'; end if;
 update delivery_orders set status=p_status where id=p_id;
 if p_status='DELIVERED' then insert into delivery_proofs(order_id,driver_id,recipient_name) values(p_id,auth.uid(),left(p_recipient,120)); end if;
end $$;

revoke execute on function admin_add_driver(text,text,text),driver_me(),driver_set_online(boolean),driver_orders(),driver_update_status(uuid,text,text) from public, anon;
grant execute on function admin_add_driver(text,text,text),driver_me(),driver_set_online(boolean),driver_orders(),driver_update_status(uuid,text,text) to authenticated;

-- ===== 005_google_driver.sql =====
-- ALLO JIB — étape 4 : inscription livreur via Google (activation manuelle par l'admin)
alter table driver_profiles add column if not exists email text;
alter table driver_profiles alter column full_name drop not null;

create or replace function driver_signup(p_phone text default null) returns jsonb language plpgsql security definer set search_path=public as $$
declare u record; nm text;
begin
 if auth.uid() is null then raise exception 'connexion requise'; end if;
 select email, coalesce(raw_user_meta_data->>'full_name', raw_user_meta_data->>'name', email) as nm into u from auth.users where id=auth.uid();
 insert into driver_profiles(user_id,full_name,email,phone,active) values(auth.uid(),left(u.nm,120),u.email,left(p_phone,30),false)
 on conflict(user_id) do update set phone=coalesce(nullif(left(p_phone,30),''),driver_profiles.phone), email=excluded.email;
 return (select jsonb_build_object('active',active,'name',full_name,'phone',phone) from driver_profiles where user_id=auth.uid());
end $$;
revoke execute on function driver_signup(text) from public, anon;
grant execute on function driver_signup(text) to authenticated;

-- ===== 006_notifications_proofs.sql =====
-- ALLO JIB — étape 5 : notifications internes + photo de preuve de livraison

-- ===== Notifications (in-app) =====
create table if not exists notifications(
  id bigserial primary key, audience text not null check(audience in('admin','driver')),
  user_id uuid, title text not null, body text, order_id uuid references delivery_orders(id) on delete cascade,
  read boolean not null default false, created_at timestamptz default now());
create index if not exists notif_aud on notifications(audience,user_id,read,created_at desc);
alter table notifications enable row level security;
drop policy if exists notif_admin on notifications; create policy notif_admin on notifications for all using (is_admin()) with check (is_admin());
drop policy if exists notif_driver_sel on notifications; create policy notif_driver_sel on notifications for select using (audience='driver' and user_id=auth.uid());
drop policy if exists notif_driver_upd on notifications; create policy notif_driver_upd on notifications for update using (audience='driver' and user_id=auth.uid()) with check (audience='driver' and user_id=auth.uid());
grant select,insert,update,delete on notifications to authenticated; revoke all on notifications from anon;
grant usage,select on all sequences in schema public to authenticated;

create or replace function notify_order_insert() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into notifications(audience,title,body,order_id) values('admin','طلب جديد '||new.ref,new.customer_name||' · '||new.fee||' درهم',new.id); return new; end $$;
drop trigger if exists trg_notify_order_insert on delivery_orders;
create trigger trg_notify_order_insert after insert on delivery_orders for each row execute function notify_order_insert();

create or replace function notify_order_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.driver_id is distinct from old.driver_id then
  if new.driver_id is not null then insert into notifications(audience,user_id,title,body,order_id) values('driver',new.driver_id,'طلب جديد معيّن لك',new.ref,new.id); end if;
  if old.driver_id is not null then insert into notifications(audience,user_id,title,body,order_id) values('driver',old.driver_id,'تم سحب الطلب منك',new.ref,new.id); end if;
 end if;
 if new.status is distinct from old.status then
  if new.status in('DELIVERED','FAILED_DELIVERY') then insert into notifications(audience,title,body,order_id) values('admin',case when new.status='DELIVERED' then 'تم التوصيل ' else 'فشل التوصيل ' end||new.ref,null,new.id); end if;
  if new.status='CANCELLED' and new.driver_id is not null then insert into notifications(audience,user_id,title,body,order_id) values('driver',new.driver_id,'تم إلغاء الطلب',new.ref,new.id); end if;
 end if;
 return new;
end $$;
drop trigger if exists trg_notify_order_update on delivery_orders;
create trigger trg_notify_order_update after update on delivery_orders for each row execute function notify_order_update();

create or replace function notify_admin_generic() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if tg_table_name='driver_applications' then insert into notifications(audience,title,body) values('admin','طلب توظيف جديد',new.full_name||' · '||new.ref);
 elsif tg_table_name='business_requests' then insert into notifications(audience,title,body) values('admin','طلب تعاون من محل',new.business_name);
 elsif tg_table_name='driver_profiles' and new.active=false then insert into notifications(audience,title,body) values('admin','سائق جديد ينتظر التفعيل',coalesce(new.full_name,new.email)); end if;
 return new;
end $$;
drop trigger if exists trg_n_app on driver_applications; create trigger trg_n_app after insert on driver_applications for each row execute function notify_admin_generic();
drop trigger if exists trg_n_biz on business_requests; create trigger trg_n_biz after insert on business_requests for each row execute function notify_admin_generic();
drop trigger if exists trg_n_drv on driver_profiles; create trigger trg_n_drv after insert on driver_profiles for each row execute function notify_admin_generic();

-- ===== Photo de preuve (bucket privé) =====
alter table delivery_proofs add column if not exists photo_path text;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
 values('proofs','proofs',false,3145728,array['image/jpeg','image/png','image/webp']) on conflict(id) do nothing;
drop policy if exists proofs_driver_insert on storage.objects;
create policy proofs_driver_insert on storage.objects for insert to authenticated
 with check (bucket_id='proofs' and exists(select 1 from public.delivery_orders o where o.id::text=(storage.foldername(name))[1] and o.driver_id=auth.uid()));
drop policy if exists proofs_admin_select on storage.objects;
create policy proofs_admin_select on storage.objects for select to authenticated using (bucket_id='proofs' and public.is_admin());

drop function if exists driver_update_status(uuid,text,text);
create or replace function driver_update_status(p_id uuid,p_status text,p_recipient text default null,p_photo text default null) returns void language plpgsql security definer set search_path=public as $$
declare cur text; ok boolean;
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 select status into cur from delivery_orders where id=p_id and driver_id=auth.uid();
 if cur is null then raise exception 'commande introuvable'; end if;
 ok := (cur='DRIVER_ASSIGNED' and p_status='PICKUP_IN_PROGRESS') or (cur='PICKUP_IN_PROGRESS' and p_status='PICKED_UP')
    or (cur='PICKED_UP' and p_status='IN_TRANSIT') or (cur='IN_TRANSIT' and p_status in('DELIVERED','FAILED_DELIVERY'))
    or (cur='PICKED_UP' and p_status='FAILED_DELIVERY');
 if not ok then raise exception 'transition interdite'; end if;
 if p_photo is not null and left(p_photo,37)<>p_id::text||'/' then raise exception 'photo invalide'; end if;
 update delivery_orders set status=p_status where id=p_id;
 if p_status='DELIVERED' then insert into delivery_proofs(order_id,driver_id,recipient_name,photo_path) values(p_id,auth.uid(),left(p_recipient,120),left(p_photo,200)); end if;
end $$;
revoke execute on function driver_update_status(uuid,text,text,text) from public, anon;
grant execute on function driver_update_status(uuid,text,text,text) to authenticated;

-- ===== 007_dispatch.sql =====
-- ALLO JIB — étape 6 : dispatch automatique + acceptation par le livreur
alter table delivery_orders add column if not exists accepted_at timestamptz, add column if not exists offered_at timestamptz, add column if not exists declined_by uuid[] not null default '{}';
alter table driver_profiles add column if not exists last_assigned_at timestamptz;
alter table pricing_settings add column if not exists auto_dispatch boolean not null default true, add column if not exists offer_timeout_min int not null default 3;

-- Une réaffectation par l'admin remet l'acceptation à zéro
create or replace function on_order_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
  new.updated_at := now();
  if new.driver_id is distinct from old.driver_id then new.accepted_at := null; end if;
  if new.status is distinct from old.status then
    insert into order_status_history(order_id,status,changed_by) values(new.id,new.status,auth.uid());
  end if;
  return new;
end $$;

-- Dispatcher : réaffecte les offres expirées, puis donne chaque commande en attente à un livreur libre
create or replace function dispatch_pending() returns void language plpgsql security definer set search_path=public as $$
declare s pricing_settings; o record; d uuid;
begin
 perform pg_advisory_xact_lock(7001);
 select * into s from pricing_settings where id=1;
 update delivery_orders set declined_by=array_append(declined_by,driver_id), driver_id=null, status='CONFIRMED', offered_at=null
  where status='DRIVER_ASSIGNED' and accepted_at is null and offered_at is not null and offered_at < now()-make_interval(mins=>s.offer_timeout_min);
 if not s.auto_dispatch then return; end if;
 for o in select id,declined_by,created_at from delivery_orders where status='CONFIRMED' and driver_id is null order by created_at loop
  d := null;
  select p.user_id into d from driver_profiles p
   where p.active and p.online
     and not exists(select 1 from delivery_orders x where x.driver_id=p.user_id and x.status in('DRIVER_ASSIGNED','PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT'))
     and (p.user_id <> all(o.declined_by) or o.created_at < now()-interval '15 minutes')
   order by p.last_assigned_at nulls first limit 1;
  if d is not null then
   update delivery_orders set driver_id=d, status='DRIVER_ASSIGNED', offered_at=now(), accepted_at=null where id=o.id;
   update driver_profiles set last_assigned_at=now() where user_id=d;
  end if;
 end loop;
end $$;
revoke execute on function dispatch_pending() from public, anon, authenticated;

-- Confirmation automatique des nouvelles commandes (désactivable dans admin > الأثمنة)
create or replace function order_autoconfirm() returns trigger language plpgsql security definer set search_path=public as $$
begin if (select auto_dispatch from pricing_settings where id=1) then new.status:='CONFIRMED'; end if; return new; end $$;
drop trigger if exists trg_order_autoconfirm on delivery_orders;
create trigger trg_order_autoconfirm before insert on delivery_orders for each row execute function order_autoconfirm();

create or replace function create_order(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare km numeric; f numeric; r text; oid uuid;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 if length(coalesce(p->>'customer_name',''))<2 or length(coalesce(p->>'pickup_address',''))<3 or length(coalesce(p->>'dest_address',''))<3 then raise exception 'champs requis'; end if;
 km := route_km((p->>'pickup_zone')::uuid,(p->>'dest_zone')::uuid); f := calc_fee(km);
 r := 'AJ-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into delivery_orders(ref,customer_name,phone,whatsapp,pickup_zone,pickup_address,pickup_contact,pickup_phone,pickup_link,dest_zone,dest_address,dest_contact,dest_phone,pkg_type,item_desc,pkg_size,notes,distance_km,fee)
 values(r,left(p->>'customer_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),(p->>'pickup_zone')::uuid,left(p->>'pickup_address',300),left(p->>'pickup_contact',120),left(p->>'pickup_phone',30),left(p->>'pickup_link',500),(p->>'dest_zone')::uuid,left(p->>'dest_address',300),left(p->>'dest_contact',120),left(p->>'dest_phone',30),left(p->>'pkg_type',60),left(p->>'item_desc',500),left(p->>'pkg_size',30),left(p->>'notes',500),km,f) returning id into oid;
 insert into order_status_history(order_id,status) select id,status from delivery_orders where id=oid;
 perform dispatch_pending();
 return jsonb_build_object('ref',r,'km',km,'fee',f);
end $$;

create or replace function driver_set_online(b boolean) returns void language plpgsql security definer set search_path=public as $$
begin update driver_profiles set online=b where user_id=auth.uid() and active; if b then perform dispatch_pending(); end if; end $$;

-- Avant acceptation : zones, prix, distance seulement. Après : adresses et téléphones.
create or replace function driver_orders() returns jsonb language plpgsql volatile security definer set search_path=public as $$
declare s pricing_settings; r jsonb;
begin
 perform dispatch_pending();
 select * into s from pricing_settings where id=1;
 select coalesce(jsonb_agg(x order by (x->>'created_at') desc),'[]'::jsonb) into r from (
  select jsonb_build_object('id',o.id,'ref',o.ref,'status',o.status,'created_at',o.created_at,'updated_at',o.updated_at,
   'accepted',(o.accepted_at is not null or o.status<>'DRIVER_ASSIGNED'),
   'offer_left',case when o.status='DRIVER_ASSIGNED' and o.accepted_at is null and o.offered_at is not null then greatest(0,floor(s.offer_timeout_min*60-extract(epoch from now()-o.offered_at))) else null end,
   'pickup_zone',a.name,'dest_zone',b.name,'fee',o.fee,'km',o.distance_km,'item_desc',o.item_desc,'pkg_size',o.pkg_size,
   'pickup_address',case when v then o.pickup_address end,'pickup_contact',case when v then o.pickup_contact end,'pickup_phone',case when v then coalesce(nullif(o.pickup_phone,''),o.phone) end,'pickup_link',case when v then o.pickup_link end,
   'dest_address',case when v then o.dest_address end,'dest_contact',case when v then o.dest_contact end,'dest_phone',case when v then o.dest_phone end,'notes',case when v then o.notes end,
   'customer_name',case when v then o.customer_name end,'customer_phone',case when v then o.phone end) x
  from (select oo.*, not (oo.status='DRIVER_ASSIGNED' and oo.accepted_at is null) as v from delivery_orders oo) o
  left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
  where o.driver_id=auth.uid() and exists(select 1 from driver_profiles where user_id=auth.uid() and active)
  order by o.created_at desc limit 100) s2;
 return r;
end $$;

create or replace function driver_accept(p_id uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 perform dispatch_pending();
 update delivery_orders set accepted_at=now() where id=p_id and driver_id=auth.uid() and status='DRIVER_ASSIGNED' and accepted_at is null;
 if not found then raise exception 'العرض انتهى أو ماشي ليك'; end if;
end $$;

create or replace function driver_decline(p_id uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 update delivery_orders set declined_by=array_append(declined_by,auth.uid()), driver_id=null, status='CONFIRMED', offered_at=null
  where id=p_id and driver_id=auth.uid() and status='DRIVER_ASSIGNED' and accepted_at is null;
 if not found then raise exception 'impossible de refuser'; end if;
 perform dispatch_pending();
end $$;

create or replace function driver_update_status(p_id uuid,p_status text,p_recipient text default null,p_photo text default null) returns void language plpgsql security definer set search_path=public as $$
declare cur text; acc timestamptz; ok boolean;
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 select status,accepted_at into cur,acc from delivery_orders where id=p_id and driver_id=auth.uid();
 if cur is null then raise exception 'commande introuvable'; end if;
 ok := (cur='DRIVER_ASSIGNED' and acc is not null and p_status='PICKUP_IN_PROGRESS') or (cur='PICKUP_IN_PROGRESS' and p_status='PICKED_UP')
    or (cur='PICKED_UP' and p_status='IN_TRANSIT') or (cur='IN_TRANSIT' and p_status in('DELIVERED','FAILED_DELIVERY'))
    or (cur='PICKED_UP' and p_status='FAILED_DELIVERY');
 if not ok then raise exception 'transition interdite'; end if;
 if p_photo is not null and left(p_photo,37)<>p_id::text||'/' then raise exception 'photo invalide'; end if;
 update delivery_orders set status=p_status where id=p_id;
 if p_status='DELIVERED' then insert into delivery_proofs(order_id,driver_id,recipient_name,photo_path) values(p_id,auth.uid(),left(p_recipient,120),left(p_photo,200)); end if;
 if p_status in('DELIVERED','FAILED_DELIVERY') then perform dispatch_pending(); end if;
end $$;

revoke execute on function driver_accept(uuid),driver_decline(uuid) from public, anon;
grant execute on function driver_accept(uuid),driver_decline(uuid) to authenticated;

-- ===== 008_required_contacts.sql =====
-- ALLO JIB : nom et téléphone obligatoires pour le contact d'enlèvement et le destinataire (service à la demande)
create or replace function create_order(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare km numeric; f numeric; r text; oid uuid;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 if length(coalesce(p->>'pickup_contact',''))<2 or length(coalesce(p->>'dest_contact',''))<2 then raise exception 'contacts requis'; end if;
 if not valid_ma_phone(p->>'pickup_phone') or not valid_ma_phone(p->>'dest_phone') then raise exception 'phone contact invalide'; end if;
 if length(coalesce(p->>'customer_name',''))<2 or length(coalesce(p->>'pickup_address',''))<3 or length(coalesce(p->>'dest_address',''))<3 then raise exception 'champs requis'; end if;
 km := route_km((p->>'pickup_zone')::uuid,(p->>'dest_zone')::uuid); f := calc_fee(km);
 r := 'AJ-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into delivery_orders(ref,customer_name,phone,whatsapp,pickup_zone,pickup_address,pickup_contact,pickup_phone,pickup_link,dest_zone,dest_address,dest_contact,dest_phone,pkg_type,item_desc,pkg_size,notes,distance_km,fee)
 values(r,left(p->>'customer_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),(p->>'pickup_zone')::uuid,left(p->>'pickup_address',300),left(p->>'pickup_contact',120),left(p->>'pickup_phone',30),left(p->>'pickup_link',500),(p->>'dest_zone')::uuid,left(p->>'dest_address',300),left(p->>'dest_contact',120),left(p->>'dest_phone',30),left(p->>'pkg_type',60),left(p->>'item_desc',500),left(p->>'pkg_size',30),left(p->>'notes',500),km,f) returning id into oid;
 insert into order_status_history(order_id,status) select id,status from delivery_orders where id=oid;
 perform dispatch_pending();
 return jsonb_build_object('ref',r,'km',km,'fee',f);
end $$;


-- ===== 009_ondemand_gps.sql =====
-- ALLO JIB — étape 7 : « à la demande » + GPS livreur en direct (pendant une livraison active uniquement)
alter table delivery_orders add column if not exists dest_lat numeric, add column if not exists dest_lng numeric;

create table if not exists driver_locations(
  driver_id uuid primary key references driver_profiles(user_id) on delete cascade,
  lat numeric not null, lng numeric not null, accuracy numeric, updated_at timestamptz not null default now());
alter table driver_locations enable row level security;
drop policy if exists loc_admin on driver_locations; create policy loc_admin on driver_locations for select using (is_admin());
grant select on driver_locations to authenticated; revoke all on driver_locations from anon;

create or replace function create_order(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare km numeric; f numeric; r text; oid uuid; dc text; dph text; dlat numeric; dlng numeric;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 dc := coalesce(nullif(trim(p->>'dest_contact'),''),p->>'customer_name'); dph := coalesce(nullif(trim(p->>'dest_phone'),''),p->>'phone');
 if not valid_ma_phone(dph) then raise exception 'phone destinataire invalide'; end if;
 if nullif(trim(p->>'pickup_phone'),'') is not null and not valid_ma_phone(p->>'pickup_phone') then raise exception 'phone enlevement invalide'; end if;
 dlat := nullif(p->>'dest_lat','')::numeric; dlng := nullif(p->>'dest_lng','')::numeric;
 if dlat is not null and (dlat not between 20 and 37 or dlng is null or dlng not between -18 and 0) then dlat := null; dlng := null; end if;
 if length(coalesce(p->>'customer_name',''))<2 or length(coalesce(p->>'pickup_address',''))<3 or length(coalesce(p->>'dest_address',''))<3 then raise exception 'champs requis'; end if;
 km := route_km((p->>'pickup_zone')::uuid,(p->>'dest_zone')::uuid); f := calc_fee(km);
 r := 'AJ-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into delivery_orders(ref,customer_name,phone,whatsapp,pickup_zone,pickup_address,pickup_contact,pickup_phone,pickup_link,dest_zone,dest_address,dest_contact,dest_phone,pkg_type,item_desc,pkg_size,notes,distance_km,fee,dest_lat,dest_lng)
 values(r,left(p->>'customer_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),(p->>'pickup_zone')::uuid,left(p->>'pickup_address',300),left(p->>'pickup_contact',120),left(p->>'pickup_phone',30),left(p->>'pickup_link',500),(p->>'dest_zone')::uuid,left(p->>'dest_address',300),left(dc,120),left(regexp_replace(dph,'[\s.\-]','','g'),30),left(p->>'pkg_type',60),left(p->>'item_desc',500),left(p->>'pkg_size',30),left(p->>'notes',500),km,f,dlat,dlng) returning id into oid;
 insert into order_status_history(order_id,status) select id,status from delivery_orders where id=oid;
 perform dispatch_pending();
 return jsonb_build_object('ref',r,'km',km,'fee',f);
end $$;


create or replace function driver_orders() returns jsonb language plpgsql volatile security definer set search_path=public as $$
declare s pricing_settings; r jsonb;
begin
 perform dispatch_pending();
 select * into s from pricing_settings where id=1;
 select coalesce(jsonb_agg(x order by (x->>'created_at') desc),'[]'::jsonb) into r from (
  select jsonb_build_object('id',o.id,'ref',o.ref,'status',o.status,'created_at',o.created_at,'updated_at',o.updated_at,
   'accepted',(o.accepted_at is not null or o.status<>'DRIVER_ASSIGNED'),
   'offer_left',case when o.status='DRIVER_ASSIGNED' and o.accepted_at is null and o.offered_at is not null then greatest(0,floor(s.offer_timeout_min*60-extract(epoch from now()-o.offered_at))) else null end,
   'pickup_zone',a.name,'dest_zone',b.name,'fee',o.fee,'km',o.distance_km,'item_desc',o.item_desc,'pkg_size',o.pkg_size,
   'pickup_address',case when v then o.pickup_address end,'pickup_contact',case when v then o.pickup_contact end,'pickup_phone',case when v then nullif(o.pickup_phone,'') end,'pickup_link',case when v then o.pickup_link end,
   'dest_address',case when v then o.dest_address end,'dest_contact',case when v then o.dest_contact end,'dest_phone',case when v then o.dest_phone end,'notes',case when v then o.notes end,'dest_lat',case when v then o.dest_lat end,'dest_lng',case when v then o.dest_lng end,
   'customer_name',case when v then o.customer_name end,'customer_phone',case when v then o.phone end) x
  from (select oo.*, not (oo.status='DRIVER_ASSIGNED' and oo.accepted_at is null) as v from delivery_orders oo) o
  left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
  where o.driver_id=auth.uid() and exists(select 1 from driver_profiles where user_id=auth.uid() and active)
  order by o.created_at desc limit 100) s2;
 return r;
end $$;


create or replace function driver_update_location(p_lat numeric,p_lng numeric,p_acc numeric default null) returns void language plpgsql security definer set search_path=public as $$
begin
 if p_lat not between -90 and 90 or p_lng not between -180 and 180 then raise exception 'coordonnées invalides'; end if;
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 if not exists(select 1 from delivery_orders where driver_id=auth.uid() and status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT')) then
  delete from driver_locations where driver_id=auth.uid(); return;
 end if;
 insert into driver_locations(driver_id,lat,lng,accuracy,updated_at) values(auth.uid(),p_lat,p_lng,p_acc,now())
 on conflict(driver_id) do update set lat=excluded.lat,lng=excluded.lng,accuracy=excluded.accuracy,updated_at=now();
end $$;
revoke execute on function driver_update_location(numeric,numeric,numeric) from public, anon;
grant execute on function driver_update_location(numeric,numeric,numeric) to authenticated;

-- La position est supprimée dès qu'il n'y a plus de livraison active
create or replace function cleanup_driver_location() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.driver_id is not null and new.status in('DELIVERED','FAILED_DELIVERY','CANCELLED','RETURNED')
    and not exists(select 1 from delivery_orders where driver_id=new.driver_id and status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT')) then
  delete from driver_locations where driver_id=new.driver_id;
 end if;
 return new;
end $$;
drop trigger if exists trg_cleanup_loc on delivery_orders;
create trigger trg_cleanup_loc after update of status on delivery_orders for each row execute function cleanup_driver_location();

-- Suivi client : position du livreur seulement pendant la livraison et si fraîche (< 3 min)
create or replace function track_order(p_ref text,p_phone text) returns jsonb language sql stable security definer set search_path=public as $$
 select jsonb_build_object('ref',o.ref,'status',o.status,'pickup',a.name,'dest',b.name,'fee',o.fee,'updated_at',o.updated_at,
  'dest_lat',o.dest_lat,'dest_lng',o.dest_lng,
  'driver_name',case when o.driver_id is not null and o.status in('DRIVER_ASSIGNED','PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT') then split_part(coalesce(dp.full_name,''),' ',1) end,
  'driver_lat',case when o.status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT') and l.updated_at>now()-interval '3 minutes' then l.lat end,
  'driver_lng',case when o.status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT') and l.updated_at>now()-interval '3 minutes' then l.lng end,
  'driver_at',case when o.status in('PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT') and l.updated_at>now()-interval '3 minutes' then l.updated_at end)
 from delivery_orders o left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
 left join driver_profiles dp on dp.user_id=o.driver_id left join driver_locations l on l.driver_id=o.driver_id
 where o.ref=upper(trim(p_ref)) and o.phone=regexp_replace(p_phone,'[\s.\-]','','g') $$;

-- ===== 010_push.sql =====
-- ALLO JIB — étape 8 : jetons de notification push (application livreur)
create table if not exists device_tokens(
  token text primary key, user_id uuid not null references auth.users(id) on delete cascade,
  platform text, updated_at timestamptz not null default now());
create index if not exists device_user on device_tokens(user_id);
alter table device_tokens enable row level security;
drop policy if exists dt_admin on device_tokens; create policy dt_admin on device_tokens for select using (is_admin());
grant select on device_tokens to authenticated; revoke all on device_tokens from anon;

create or replace function register_device(p_token text,p_platform text default null) returns void language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 if length(coalesce(p_token,''))<20 then raise exception 'jeton invalide'; end if;
 insert into device_tokens(token,user_id,platform) values(p_token,auth.uid(),left(p_platform,20))
 on conflict(token) do update set user_id=auth.uid(), platform=excluded.platform, updated_at=now();
end $$;
revoke execute on function register_device(text,text) from public, anon;
grant execute on function register_device(text,text) to authenticated;
