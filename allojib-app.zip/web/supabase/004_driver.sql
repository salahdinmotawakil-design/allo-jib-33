-- ALLO JIB — étape 3 : espace livreur
create table if not exists driver_profiles(
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null, phone text, active boolean not null default true, online boolean not null default false,
  created_at timestamptz default now());
alter table delivery_orders add column if not exists driver_id uuid references driver_profiles(user_id);
create index if not exists orders_driver on delivery_orders(driver_id,status);

create table if not exists delivery_proofs(
  id bigserial primary key, order_id uuid references delivery_orders(id) on delete cascade,
  driver_id uuid, recipient_name text, created_at timestamptz default now());

alter table driver_profiles enable row level security; alter table delivery_proofs enable row level security;
drop policy if exists dp_admin on driver_profiles; create policy dp_admin on driver_profiles for all using (is_admin()) with check (is_admin());
drop policy if exists dp_self on driver_profiles; create policy dp_self on driver_profiles for select using (user_id=auth.uid());
drop policy if exists proof_admin on delivery_proofs; create policy proof_admin on delivery_proofs for all using (is_admin()) with check (is_admin());

grant select,insert,update,delete on driver_profiles, delivery_proofs to authenticated;
grant usage,select on all sequences in schema public to authenticated;
revoke all on driver_profiles, delivery_proofs from anon;

-- Admin : lier un compte Auth existant à un livreur (jamais d'auto-approbation)
create or replace function admin_add_driver(p_email text,p_name text,p_phone text) returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid;
begin
 if not is_admin() then raise exception 'interdit'; end if;
 select id into uid from auth.users where lower(email)=lower(trim(p_email));
 if uid is null then raise exception 'compte introuvable : créez-le dans Authentication > Users'; end if;
 insert into driver_profiles(user_id,full_name,phone) values(uid,left(p_name,120),left(p_phone,30))
 on conflict(user_id) do update set full_name=excluded.full_name, phone=excluded.phone, active=true;
 return jsonb_build_object('user_id',uid);
end $$;

create or replace function driver_me() returns jsonb language sql stable security definer set search_path=public as $$
 select to_jsonb(d) - 'created_at' from driver_profiles d where user_id=auth.uid() and active $$;

create or replace function driver_set_online(b boolean) returns void language plpgsql security definer set search_path=public as $$
begin update driver_profiles set online=b where user_id=auth.uid() and active; end $$;

-- Le livreur ne voit que SES commandes et seulement les champs nécessaires
create or replace function driver_orders() returns jsonb language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(x order by (x->>'created_at') desc),'[]'::jsonb) from (
  select jsonb_build_object('id',o.id,'ref',o.ref,'status',o.status,'created_at',o.created_at,'updated_at',o.updated_at,
   'pickup_zone',a.name,'pickup_address',o.pickup_address,'pickup_contact',o.pickup_contact,'pickup_phone',coalesce(nullif(o.pickup_phone,''),o.phone),'pickup_link',o.pickup_link,
   'dest_zone',b.name,'dest_address',o.dest_address,'dest_contact',o.dest_contact,'dest_phone',o.dest_phone,
   'item_desc',o.item_desc,'pkg_size',o.pkg_size,'notes',o.notes,'fee',o.fee) x
  from delivery_orders o left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
  where o.driver_id=auth.uid() and exists(select 1 from driver_profiles where user_id=auth.uid() and active)
  order by o.created_at desc limit 100) s $$;

-- Workflow sécurisé : seules ces transitions sont permises au livreur
create or replace function driver_update_status(p_id uuid,p_status text,p_recipient text default null) returns void language plpgsql security definer set search_path=public as $$
declare cur text; ok boolean;
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 select status into cur from delivery_orders where id=p_id and driver_id=auth.uid();
 if cur is null then raise exception 'commande introuvable'; end if;
 ok := (cur='DRIVER_ASSIGNED' and p_status='PICKUP_IN_PROGRESS') or (cur='PICKUP_IN_PROGRESS' and p_status='PICKED_UP')
    or (cur='PICKED_UP' and p_status='IN_TRANSIT') or (cur='IN_TRANSIT' and p_status in('DELIVERED','FAILED_DELIVERY'))
    or (cur='PICKED_UP' and p_status='FAILED_DELIVERY');
 if not ok then raise exception 'transition interdite'; end if;
 update delivery_orders set status=p_status where id=p_id;
 if p_status='DELIVERED' then insert into delivery_proofs(order_id,driver_id,recipient_name) values(p_id,auth.uid(),left(p_recipient,120)); end if;
end $$;

revoke execute on function admin_add_driver(text,text,text),driver_me(),driver_set_online(boolean),driver_orders(),driver_update_status(uuid,text,text) from public, anon;
grant execute on function admin_add_driver(text,text,text),driver_me(),driver_set_online(boolean),driver_orders(),driver_update_status(uuid,text,text) to authenticated;
