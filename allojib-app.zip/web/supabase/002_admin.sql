-- ALLO JIB — étape 2 : historique automatique des statuts
create or replace function on_order_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
  new.updated_at := now();
  if new.status is distinct from old.status then
    insert into order_status_history(order_id,status,changed_by) values(new.id,new.status,auth.uid());
  end if;
  return new;
end $$;
drop trigger if exists trg_order_update on delivery_orders;
create trigger trg_order_update before update on delivery_orders for each row execute function on_order_update();

-- Un admin peut lire sa propre ligne (sert à vérifier l'accès au login)
drop policy if exists admins_self on admins;
drop policy if exists admins_self on admins; create policy admins_self on admins for select using (user_id = auth.uid());
