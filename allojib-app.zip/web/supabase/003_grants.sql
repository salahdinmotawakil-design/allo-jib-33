-- ALLO JIB : accès API (les nouveaux projets Supabase n'exposent plus les tables automatiquement)
grant usage on schema public to anon, authenticated;
grant select on delivery_zones, pricing_settings to anon, authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant usage, select on all sequences in schema public to authenticated;
revoke all on delivery_orders, order_status_history, driver_applications, business_requests, admins from anon;
-- La sécurité réelle reste assurée par les policies RLS (réservées à l'admin).
