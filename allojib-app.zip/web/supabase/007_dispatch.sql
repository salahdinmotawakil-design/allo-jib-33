-- ALLO JIB — étape 6 : dispatch automatique + acceptation par le livreur
alter table delivery_orders add column if not exists accepted_at timestamptz, add column if not exists offered_at timestamptz, add column if not exists declined_by uuid[] not null default '{}';
alter table driver_profiles add column if not exists last_assigned_at timestamptz;
alter table pricing_settings add column if not exists auto_dispatch boolean not null default true, add column if not exists offer_timeout_min int not null default 3;

-- Une réaffectation par l'admin remet l'acceptation à zéro
create or replace function on_order_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
  new.updated_at := now();
  if new.driver_id is distinct from old.driver_id then new.accepted_at := null; end if;
  if new.status is distinct from old.status then
    insert into order_status_history(order_id,status,changed_by) values(new.id,new.status,auth.uid());
  end if;
  return new;
end $$;

-- Dispatcher : réaffecte les offres expirées, puis donne chaque commande en attente à un livreur libre
create or replace function dispatch_pending() returns void language plpgsql security definer set search_path=public as $$
declare s pricing_settings; o record; d uuid;
begin
 perform pg_advisory_xact_lock(7001);
 select * into s from pricing_settings where id=1;
 update delivery_orders set declined_by=array_append(declined_by,driver_id), driver_id=null, status='CONFIRMED', offered_at=null
  where status='DRIVER_ASSIGNED' and accepted_at is null and offered_at is not null and offered_at < now()-make_interval(mins=>s.offer_timeout_min);
 if not s.auto_dispatch then return; end if;
 for o in select id,declined_by,created_at from delivery_orders where status='CONFIRMED' and driver_id is null order by created_at loop
  d := null;
  select p.user_id into d from driver_profiles p
   where p.active and p.online
     and not exists(select 1 from delivery_orders x where x.driver_id=p.user_id and x.status in('DRIVER_ASSIGNED','PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT'))
     and (p.user_id <> all(o.declined_by) or o.created_at < now()-interval '15 minutes')
   order by p.last_assigned_at nulls first limit 1;
  if d is not null then
   update delivery_orders set driver_id=d, status='DRIVER_ASSIGNED', offered_at=now(), accepted_at=null where id=o.id;
   update driver_profiles set last_assigned_at=now() where user_id=d;
  end if;
 end loop;
end $$;
revoke execute on function dispatch_pending() from public, anon, authenticated;

-- Confirmation automatique des nouvelles commandes (désactivable dans admin > الأثمنة)
create or replace function order_autoconfirm() returns trigger language plpgsql security definer set search_path=public as $$
begin if (select auto_dispatch from pricing_settings where id=1) then new.status:='CONFIRMED'; end if; return new; end $$;
drop trigger if exists trg_order_autoconfirm on delivery_orders;
create trigger trg_order_autoconfirm before insert on delivery_orders for each row execute function order_autoconfirm();

create or replace function create_order(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare km numeric; f numeric; r text; oid uuid;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 if length(coalesce(p->>'customer_name',''))<2 or length(coalesce(p->>'pickup_address',''))<3 or length(coalesce(p->>'dest_address',''))<3 then raise exception 'champs requis'; end if;
 km := route_km((p->>'pickup_zone')::uuid,(p->>'dest_zone')::uuid); f := calc_fee(km);
 r := 'AJ-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into delivery_orders(ref,customer_name,phone,whatsapp,pickup_zone,pickup_address,pickup_contact,pickup_phone,pickup_link,dest_zone,dest_address,dest_contact,dest_phone,pkg_type,item_desc,pkg_size,notes,distance_km,fee)
 values(r,left(p->>'customer_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),(p->>'pickup_zone')::uuid,left(p->>'pickup_address',300),left(p->>'pickup_contact',120),left(p->>'pickup_phone',30),left(p->>'pickup_link',500),(p->>'dest_zone')::uuid,left(p->>'dest_address',300),left(p->>'dest_contact',120),left(p->>'dest_phone',30),left(p->>'pkg_type',60),left(p->>'item_desc',500),left(p->>'pkg_size',30),left(p->>'notes',500),km,f) returning id into oid;
 insert into order_status_history(order_id,status) select id,status from delivery_orders where id=oid;
 perform dispatch_pending();
 return jsonb_build_object('ref',r,'km',km,'fee',f);
end $$;

create or replace function driver_set_online(b boolean) returns void language plpgsql security definer set search_path=public as $$
begin update driver_profiles set online=b where user_id=auth.uid() and active; if b then perform dispatch_pending(); end if; end $$;

-- Avant acceptation : zones, prix, distance seulement. Après : adresses et téléphones.
create or replace function driver_orders() returns jsonb language plpgsql volatile security definer set search_path=public as $$
declare s pricing_settings; r jsonb;
begin
 perform dispatch_pending();
 select * into s from pricing_settings where id=1;
 select coalesce(jsonb_agg(x order by (x->>'created_at') desc),'[]'::jsonb) into r from (
  select jsonb_build_object('id',o.id,'ref',o.ref,'status',o.status,'created_at',o.created_at,'updated_at',o.updated_at,
   'accepted',(o.accepted_at is not null or o.status<>'DRIVER_ASSIGNED'),
   'offer_left',case when o.status='DRIVER_ASSIGNED' and o.accepted_at is null and o.offered_at is not null then greatest(0,floor(s.offer_timeout_min*60-extract(epoch from now()-o.offered_at))) else null end,
   'pickup_zone',a.name,'dest_zone',b.name,'fee',o.fee,'km',o.distance_km,'item_desc',o.item_desc,'pkg_size',o.pkg_size,
   'pickup_address',case when v then o.pickup_address end,'pickup_contact',case when v then o.pickup_contact end,'pickup_phone',case when v then coalesce(nullif(o.pickup_phone,''),o.phone) end,'pickup_link',case when v then o.pickup_link end,
   'dest_address',case when v then o.dest_address end,'dest_contact',case when v then o.dest_contact end,'dest_phone',case when v then o.dest_phone end,'notes',case when v then o.notes end,
   'customer_name',case when v then o.customer_name end,'customer_phone',case when v then o.phone end) x
  from (select oo.*, not (oo.status='DRIVER_ASSIGNED' and oo.accepted_at is null) as v from delivery_orders oo) o
  left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
  where o.driver_id=auth.uid() and exists(select 1 from driver_profiles where user_id=auth.uid() and active)
  order by o.created_at desc limit 100) s2;
 return r;
end $$;

create or replace function driver_accept(p_id uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 perform dispatch_pending();
 update delivery_orders set accepted_at=now() where id=p_id and driver_id=auth.uid() and status='DRIVER_ASSIGNED' and accepted_at is null;
 if not found then raise exception 'العرض انتهى أو ماشي ليك'; end if;
end $$;

create or replace function driver_decline(p_id uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 update delivery_orders set declined_by=array_append(declined_by,auth.uid()), driver_id=null, status='CONFIRMED', offered_at=null
  where id=p_id and driver_id=auth.uid() and status='DRIVER_ASSIGNED' and accepted_at is null;
 if not found then raise exception 'impossible de refuser'; end if;
 perform dispatch_pending();
end $$;

create or replace function driver_update_status(p_id uuid,p_status text,p_recipient text default null,p_photo text default null) returns void language plpgsql security definer set search_path=public as $$
declare cur text; acc timestamptz; ok boolean;
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 select status,accepted_at into cur,acc from delivery_orders where id=p_id and driver_id=auth.uid();
 if cur is null then raise exception 'commande introuvable'; end if;
 ok := (cur='DRIVER_ASSIGNED' and acc is not null and p_status='PICKUP_IN_PROGRESS') or (cur='PICKUP_IN_PROGRESS' and p_status='PICKED_UP')
    or (cur='PICKED_UP' and p_status='IN_TRANSIT') or (cur='IN_TRANSIT' and p_status in('DELIVERED','FAILED_DELIVERY'))
    or (cur='PICKED_UP' and p_status='FAILED_DELIVERY');
 if not ok then raise exception 'transition interdite'; end if;
 if p_photo is not null and left(p_photo,37)<>p_id::text||'/' then raise exception 'photo invalide'; end if;
 update delivery_orders set status=p_status where id=p_id;
 if p_status='DELIVERED' then insert into delivery_proofs(order_id,driver_id,recipient_name,photo_path) values(p_id,auth.uid(),left(p_recipient,120),left(p_photo,200)); end if;
 if p_status in('DELIVERED','FAILED_DELIVERY') then perform dispatch_pending(); end if;
end $$;

revoke execute on function driver_accept(uuid),driver_decline(uuid) from public, anon;
grant execute on function driver_accept(uuid),driver_decline(uuid) to authenticated;
