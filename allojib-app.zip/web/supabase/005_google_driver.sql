-- ALLO JIB — étape 4 : inscription livreur via Google (activation manuelle par l'admin)
alter table driver_profiles add column if not exists email text;
alter table driver_profiles alter column full_name drop not null;

create or replace function driver_signup(p_phone text default null) returns jsonb language plpgsql security definer set search_path=public as $$
declare u record; nm text;
begin
 if auth.uid() is null then raise exception 'connexion requise'; end if;
 select email, coalesce(raw_user_meta_data->>'full_name', raw_user_meta_data->>'name', email) as nm into u from auth.users where id=auth.uid();
 insert into driver_profiles(user_id,full_name,email,phone,active) values(auth.uid(),left(u.nm,120),u.email,left(p_phone,30),false)
 on conflict(user_id) do update set phone=coalesce(nullif(left(p_phone,30),''),driver_profiles.phone), email=excluded.email;
 return (select jsonb_build_object('active',active,'name',full_name,'phone',phone) from driver_profiles where user_id=auth.uid());
end $$;
revoke execute on function driver_signup(text) from public, anon;
grant execute on function driver_signup(text) to authenticated;
