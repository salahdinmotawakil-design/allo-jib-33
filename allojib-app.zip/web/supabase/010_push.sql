-- ALLO JIB — étape 8 : jetons de notification push (application livreur)
create table if not exists device_tokens(
  token text primary key, user_id uuid not null references auth.users(id) on delete cascade,
  platform text, updated_at timestamptz not null default now());
create index if not exists device_user on device_tokens(user_id);
alter table device_tokens enable row level security;
drop policy if exists dt_admin on device_tokens; create policy dt_admin on device_tokens for select using (is_admin());
grant select on device_tokens to authenticated; revoke all on device_tokens from anon;

create or replace function register_device(p_token text,p_platform text default null) returns void language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 if length(coalesce(p_token,''))<20 then raise exception 'jeton invalide'; end if;
 insert into device_tokens(token,user_id,platform) values(p_token,auth.uid(),left(p_platform,20))
 on conflict(token) do update set user_id=auth.uid(), platform=excluded.platform, updated_at=now();
end $$;
revoke execute on function register_device(text,text) from public, anon;
grant execute on function register_device(text,text) to authenticated;
