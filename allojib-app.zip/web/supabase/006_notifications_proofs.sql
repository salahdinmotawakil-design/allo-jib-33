-- ALLO JIB — étape 5 : notifications internes + photo de preuve de livraison

-- ===== Notifications (in-app) =====
create table if not exists notifications(
  id bigserial primary key, audience text not null check(audience in('admin','driver')),
  user_id uuid, title text not null, body text, order_id uuid references delivery_orders(id) on delete cascade,
  read boolean not null default false, created_at timestamptz default now());
create index if not exists notif_aud on notifications(audience,user_id,read,created_at desc);
alter table notifications enable row level security;
drop policy if exists notif_admin on notifications; create policy notif_admin on notifications for all using (is_admin()) with check (is_admin());
drop policy if exists notif_driver_sel on notifications; create policy notif_driver_sel on notifications for select using (audience='driver' and user_id=auth.uid());
drop policy if exists notif_driver_upd on notifications; create policy notif_driver_upd on notifications for update using (audience='driver' and user_id=auth.uid()) with check (audience='driver' and user_id=auth.uid());
grant select,insert,update,delete on notifications to authenticated; revoke all on notifications from anon;
grant usage,select on all sequences in schema public to authenticated;

create or replace function notify_order_insert() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into notifications(audience,title,body,order_id) values('admin','طلب جديد '||new.ref,new.customer_name||' · '||new.fee||' درهم',new.id); return new; end $$;
drop trigger if exists trg_notify_order_insert on delivery_orders;
create trigger trg_notify_order_insert after insert on delivery_orders for each row execute function notify_order_insert();

create or replace function notify_order_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.driver_id is distinct from old.driver_id then
  if new.driver_id is not null then insert into notifications(audience,user_id,title,body,order_id) values('driver',new.driver_id,'طلب جديد معيّن لك',new.ref,new.id); end if;
  if old.driver_id is not null then insert into notifications(audience,user_id,title,body,order_id) values('driver',old.driver_id,'تم سحب الطلب منك',new.ref,new.id); end if;
 end if;
 if new.status is distinct from old.status then
  if new.status in('DELIVERED','FAILED_DELIVERY') then insert into notifications(audience,title,body,order_id) values('admin',case when new.status='DELIVERED' then 'تم التوصيل ' else 'فشل التوصيل ' end||new.ref,null,new.id); end if;
  if new.status='CANCELLED' and new.driver_id is not null then insert into notifications(audience,user_id,title,body,order_id) values('driver',new.driver_id,'تم إلغاء الطلب',new.ref,new.id); end if;
 end if;
 return new;
end $$;
drop trigger if exists trg_notify_order_update on delivery_orders;
create trigger trg_notify_order_update after update on delivery_orders for each row execute function notify_order_update();

create or replace function notify_admin_generic() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if tg_table_name='driver_applications' then insert into notifications(audience,title,body) values('admin','طلب توظيف جديد',new.full_name||' · '||new.ref);
 elsif tg_table_name='business_requests' then insert into notifications(audience,title,body) values('admin','طلب تعاون من محل',new.business_name);
 elsif tg_table_name='driver_profiles' and new.active=false then insert into notifications(audience,title,body) values('admin','سائق جديد ينتظر التفعيل',coalesce(new.full_name,new.email)); end if;
 return new;
end $$;
drop trigger if exists trg_n_app on driver_applications; create trigger trg_n_app after insert on driver_applications for each row execute function notify_admin_generic();
drop trigger if exists trg_n_biz on business_requests; create trigger trg_n_biz after insert on business_requests for each row execute function notify_admin_generic();
drop trigger if exists trg_n_drv on driver_profiles; create trigger trg_n_drv after insert on driver_profiles for each row execute function notify_admin_generic();

-- ===== Photo de preuve (bucket privé) =====
alter table delivery_proofs add column if not exists photo_path text;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
 values('proofs','proofs',false,3145728,array['image/jpeg','image/png','image/webp']) on conflict(id) do nothing;
drop policy if exists proofs_driver_insert on storage.objects;
create policy proofs_driver_insert on storage.objects for insert to authenticated
 with check (bucket_id='proofs' and exists(select 1 from public.delivery_orders o where o.id::text=(storage.foldername(name))[1] and o.driver_id=auth.uid()));
drop policy if exists proofs_admin_select on storage.objects;
create policy proofs_admin_select on storage.objects for select to authenticated using (bucket_id='proofs' and public.is_admin());

drop function if exists driver_update_status(uuid,text,text);
create or replace function driver_update_status(p_id uuid,p_status text,p_recipient text default null,p_photo text default null) returns void language plpgsql security definer set search_path=public as $$
declare cur text; ok boolean;
begin
 if not exists(select 1 from driver_profiles where user_id=auth.uid() and active) then raise exception 'interdit'; end if;
 select status into cur from delivery_orders where id=p_id and driver_id=auth.uid();
 if cur is null then raise exception 'commande introuvable'; end if;
 ok := (cur='DRIVER_ASSIGNED' and p_status='PICKUP_IN_PROGRESS') or (cur='PICKUP_IN_PROGRESS' and p_status='PICKED_UP')
    or (cur='PICKED_UP' and p_status='IN_TRANSIT') or (cur='IN_TRANSIT' and p_status in('DELIVERED','FAILED_DELIVERY'))
    or (cur='PICKED_UP' and p_status='FAILED_DELIVERY');
 if not ok then raise exception 'transition interdite'; end if;
 if p_photo is not null and left(p_photo,37)<>p_id::text||'/' then raise exception 'photo invalide'; end if;
 update delivery_orders set status=p_status where id=p_id;
 if p_status='DELIVERED' then insert into delivery_proofs(order_id,driver_id,recipient_name,photo_path) values(p_id,auth.uid(),left(p_recipient,120),left(p_photo,200)); end if;
end $$;
revoke execute on function driver_update_status(uuid,text,text,text) from public, anon;
grant execute on function driver_update_status(uuid,text,text,text) to authenticated;
