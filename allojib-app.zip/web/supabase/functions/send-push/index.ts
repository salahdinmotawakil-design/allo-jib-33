// Edge Function Supabase « send-push » : envoie une notification push (FCM) au livreur quand une ligne est insérée dans `notifications`.
// Secrets requis : FCM_SERVICE_ACCOUNT (JSON du compte de service Firebase), WEBHOOK_SECRET (valeur libre).
// Déclencheur : Database > Webhooks > table notifications, évènement INSERT, en-tête HTTP « x-webhook-secret » = WEBHOOK_SECRET.
import { createClient } from 'npm:@supabase/supabase-js@2'
import { SignJWT, importPKCS8 } from 'npm:jose@5'

const sa = JSON.parse(Deno.env.get('FCM_SERVICE_ACCOUNT') ?? '{}')

async function accessToken(): Promise<string> {
  const key = await importPKCS8(sa.private_key, 'RS256')
  const jwt = await new SignJWT({ scope: 'https://www.googleapis.com/auth/firebase.messaging' })
    .setProtectedHeader({ alg: 'RS256' }).setIssuer(sa.client_email)
    .setAudience('https://oauth2.googleapis.com/token').setIssuedAt().setExpirationTime('55m').sign(key)
  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: jwt }) })
  return (await r.json()).access_token
}

Deno.serve(async (req) => {
  if (req.headers.get('x-webhook-secret') !== Deno.env.get('WEBHOOK_SECRET')) return new Response('forbidden', { status: 403 })
  const { record } = await req.json()
  if (!record || record.audience !== 'driver' || !record.user_id) return new Response('skip')
  const sb = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const { data } = await sb.from('device_tokens').select('token').eq('user_id', record.user_id)
  if (!data?.length) return new Response('no tokens')
  const at = await accessToken()
  for (const t of data) {
    const r = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: 'POST', headers: { Authorization: `Bearer ${at}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: { token: t.token, notification: { title: record.title, body: record.body ?? '' }, android: { priority: 'HIGH' } } }) })
    if (r.status === 404 || r.status === 400) await sb.from('device_tokens').delete().eq('token', t.token)
  }
  return new Response('ok')
})
