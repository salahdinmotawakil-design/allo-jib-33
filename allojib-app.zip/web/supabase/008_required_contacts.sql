-- ALLO JIB : nom et téléphone obligatoires pour le contact d'enlèvement et le destinataire (service à la demande)
create or replace function create_order(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare km numeric; f numeric; r text; oid uuid;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 if length(coalesce(p->>'pickup_contact',''))<2 or length(coalesce(p->>'dest_contact',''))<2 then raise exception 'contacts requis'; end if;
 if not valid_ma_phone(p->>'pickup_phone') or not valid_ma_phone(p->>'dest_phone') then raise exception 'phone contact invalide'; end if;
 if length(coalesce(p->>'customer_name',''))<2 or length(coalesce(p->>'pickup_address',''))<3 or length(coalesce(p->>'dest_address',''))<3 then raise exception 'champs requis'; end if;
 km := route_km((p->>'pickup_zone')::uuid,(p->>'dest_zone')::uuid); f := calc_fee(km);
 r := 'AJ-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into delivery_orders(ref,customer_name,phone,whatsapp,pickup_zone,pickup_address,pickup_contact,pickup_phone,pickup_link,dest_zone,dest_address,dest_contact,dest_phone,pkg_type,item_desc,pkg_size,notes,distance_km,fee)
 values(r,left(p->>'customer_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),(p->>'pickup_zone')::uuid,left(p->>'pickup_address',300),left(p->>'pickup_contact',120),left(p->>'pickup_phone',30),left(p->>'pickup_link',500),(p->>'dest_zone')::uuid,left(p->>'dest_address',300),left(p->>'dest_contact',120),left(p->>'dest_phone',30),left(p->>'pkg_type',60),left(p->>'item_desc',500),left(p->>'pkg_size',30),left(p->>'notes',500),km,f) returning id into oid;
 insert into order_status_history(order_id,status) select id,status from delivery_orders where id=oid;
 perform dispatch_pending();
 return jsonb_build_object('ref',r,'km',km,'fee',f);
end $$;

