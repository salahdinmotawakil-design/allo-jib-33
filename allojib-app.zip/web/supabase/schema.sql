-- ALLO JIB — schéma Supabase (étape 1). Exécuter dans SQL Editor.
create extension if not exists pgcrypto;

create table if not exists pricing_settings(
  id int primary key default 1 check(id=1),
  fuel_price numeric not null default 18,        -- DH/litre (essence)
  consumption_l100 numeric not null default 2.5, -- L/100 km (hypothèse scooter, à vérifier)
  maint_per_km numeric not null default 0.30,    -- usure/huile/pneus DH/km (hypothèse)
  deadhead numeric not null default 1.5,         -- facteur retour à vide
  driver_rate numeric not null default 20,       -- DH/heure livreur incl. fatigue (hypothèse)
  speed_kmh numeric not null default 25,
  handling_min numeric not null default 10,      -- minutes collecte + remise
  margin numeric not null default 0.30,          -- marge plateforme
  min_fee numeric not null default 10,
  road_factor numeric not null default 1.3,      -- route ≈ ligne droite x 1.3
  min_km numeric not null default 2,
  whatsapp text not null default '212630451217'
);
insert into pricing_settings(id) values(1) on conflict do nothing;

create table if not exists delivery_zones(
  id uuid primary key default gen_random_uuid(),
  name text not null unique, lat numeric not null, lng numeric not null,
  note text, active boolean not null default true, created_at timestamptz default now());
-- Coordonnées APPROXIMATIVES : vérifiez et corrigez depuis Google Maps.
insert into delivery_zones(name,lat,lng,note) values
 ('القليعة',30.2900,-9.4700,'Point de départ — à vérifier'),
 ('أيت ملول',30.3344,-9.4972,'à vérifier'),
 ('إنزكان',30.3553,-9.5361,'à vérifier'),
 ('الدشيرة',30.3813,-9.5436,'à vérifier'),
 ('أكادير',30.4278,-9.5981,'à vérifier') on conflict do nothing;

create table if not exists delivery_orders(
  id uuid primary key default gen_random_uuid(), ref text unique not null,
  customer_name text not null, phone text not null, whatsapp text,
  pickup_zone uuid references delivery_zones(id), pickup_address text not null, pickup_contact text, pickup_phone text, pickup_link text,
  dest_zone uuid references delivery_zones(id), dest_address text not null, dest_contact text, dest_phone text,
  pkg_type text, item_desc text, pkg_size text, notes text,
  distance_km numeric, fee numeric, payment text default 'cash',
  status text not null default 'PENDING_CONFIRMATION' check(status in('NEW','PENDING_CONFIRMATION','CONFIRMED','DRIVER_ASSIGNED','PICKUP_IN_PROGRESS','PICKED_UP','IN_TRANSIT','DELIVERED','CANCELLED','FAILED_DELIVERY','RETURNED')),
  internal_notes text, created_at timestamptz default now(), updated_at timestamptz default now());
create index if not exists orders_phone on delivery_orders(phone);
create index if not exists orders_status on delivery_orders(status,created_at desc);

create table if not exists order_status_history(
  id bigserial primary key, order_id uuid references delivery_orders(id) on delete cascade,
  status text not null, changed_by uuid, created_at timestamptz default now());

create table if not exists driver_applications(
  id uuid primary key default gen_random_uuid(), ref text unique not null,
  full_name text not null, phone text not null, whatsapp text, city text, address text,
  has_moto boolean, moto_type text, has_licence boolean, has_docs boolean, experience text, hours text, areas text,
  consent boolean not null default false,
  status text not null default 'PENDING' check(status in('PENDING','UNDER_REVIEW','APPROVED','REJECTED','CONTACTED')),
  admin_notes text, created_at timestamptz default now());

create table if not exists business_requests(
  id uuid primary key default gen_random_uuid(), business_name text not null, owner_name text, phone text not null,
  address text, business_type text, volume text, message text, status text default 'NEW', created_at timestamptz default now());

create table if not exists admins(user_id uuid primary key references auth.users(id) on delete cascade);

-- ===== Calcul du prix (SEULE source de vérité : le serveur) =====
create or replace function haversine_km(a1 numeric,o1 numeric,a2 numeric,o2 numeric) returns numeric language sql immutable as $$
 select (6371*2*asin(sqrt(power(sin(radians(a2-a1)/2),2)+cos(radians(a1))*cos(radians(a2))*power(sin(radians(o2-o1)/2),2))))::numeric $$;

create or replace function calc_fee(km numeric) returns numeric language plpgsql stable as $$
declare s pricing_settings; eff numeric; cost numeric;
begin select * into s from pricing_settings where id=1;
 eff := km*s.deadhead;
 cost := eff*(s.consumption_l100/100*s.fuel_price + s.maint_per_km) + (km/s.speed_kmh + s.handling_min/60)*s.driver_rate;
 return greatest(s.min_fee, ceil(cost*(1+s.margin)));
end $$;

create or replace function route_km(z1 uuid,z2 uuid) returns numeric language plpgsql stable security definer set search_path=public as $$
declare a delivery_zones; b delivery_zones; s pricing_settings;
begin select * into a from delivery_zones where id=z1 and active; select * into b from delivery_zones where id=z2 and active; select * into s from pricing_settings where id=1;
 if a.id is null or b.id is null then raise exception 'zone invalide'; end if;
 return round(greatest(s.min_km, haversine_km(a.lat,a.lng,b.lat,b.lng)*s.road_factor),1);
end $$;

create or replace function valid_ma_phone(p text) returns boolean language sql immutable as $$
 select regexp_replace(coalesce(p,''),'[\s.\-]','','g') ~ '^(\+212|00212|0)[5-7][0-9]{8}$' $$;

create or replace function create_order(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare km numeric; f numeric; r text; oid uuid;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 if length(coalesce(p->>'customer_name',''))<2 or length(coalesce(p->>'pickup_address',''))<3 or length(coalesce(p->>'dest_address',''))<3 then raise exception 'champs requis'; end if;
 km := route_km((p->>'pickup_zone')::uuid,(p->>'dest_zone')::uuid); f := calc_fee(km);
 r := 'AJ-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into delivery_orders(ref,customer_name,phone,whatsapp,pickup_zone,pickup_address,pickup_contact,pickup_phone,pickup_link,dest_zone,dest_address,dest_contact,dest_phone,pkg_type,item_desc,pkg_size,notes,distance_km,fee)
 values(r,left(p->>'customer_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),(p->>'pickup_zone')::uuid,left(p->>'pickup_address',300),left(p->>'pickup_contact',120),left(p->>'pickup_phone',30),left(p->>'pickup_link',500),(p->>'dest_zone')::uuid,left(p->>'dest_address',300),left(p->>'dest_contact',120),left(p->>'dest_phone',30),left(p->>'pkg_type',60),left(p->>'item_desc',500),left(p->>'pkg_size',30),left(p->>'notes',500),km,f) returning id into oid;
 insert into order_status_history(order_id,status) values(oid,'PENDING_CONFIRMATION');
 return jsonb_build_object('ref',r,'km',km,'fee',f);
end $$;

create or replace function quote(z1 uuid,z2 uuid) returns jsonb language sql stable security definer set search_path=public as $$
 select jsonb_build_object('km',route_km(z1,z2),'fee',calc_fee(route_km(z1,z2))) $$;

create or replace function track_order(p_ref text,p_phone text) returns jsonb language sql stable security definer set search_path=public as $$
 select jsonb_build_object('ref',o.ref,'status',o.status,'pickup',a.name,'dest',b.name,'fee',o.fee,'updated_at',o.updated_at)
 from delivery_orders o left join delivery_zones a on a.id=o.pickup_zone left join delivery_zones b on b.id=o.dest_zone
 where o.ref=upper(trim(p_ref)) and o.phone=regexp_replace(p_phone,'[\s.\-]','','g') $$;

create or replace function apply_driver(p jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare r text;
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 if coalesce((p->>'consent')::boolean,false)=false or coalesce((p->>'adult')::boolean,false)=false then raise exception 'consentement requis'; end if;
 r:='DR-'||upper(substr(md5(gen_random_uuid()::text),1,6));
 insert into driver_applications(ref,full_name,phone,whatsapp,city,address,has_moto,moto_type,has_licence,has_docs,experience,hours,areas,consent)
 values(r,left(p->>'full_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'whatsapp',30),left(p->>'city',80),left(p->>'address',300),(p->>'has_moto')='yes',left(p->>'moto_type',80),(p->>'has_licence')='yes',(p->>'has_docs')='yes',left(p->>'experience',500),left(p->>'hours',200),left(p->>'areas',300),true);
 return jsonb_build_object('ref',r);
end $$;

create or replace function driver_status(p_ref text,p_phone text) returns jsonb language sql stable security definer set search_path=public as $$
 select jsonb_build_object('ref',ref,'status',status) from driver_applications where ref=upper(trim(p_ref)) and phone=regexp_replace(p_phone,'[\s.\-]','','g') $$;

create or replace function create_business_request(p jsonb) returns void language plpgsql security definer set search_path=public as $$
begin
 if not valid_ma_phone(p->>'phone') then raise exception 'phone invalide'; end if;
 insert into business_requests(business_name,owner_name,phone,address,business_type,volume,message)
 values(left(p->>'business_name',150),left(p->>'owner_name',120),regexp_replace(p->>'phone','[\s.\-]','','g'),left(p->>'address',300),left(p->>'business_type',80),left(p->>'volume',80),left(p->>'message',800));
end $$;

-- ===== Sécurité (RLS) =====
alter table pricing_settings enable row level security; alter table delivery_zones enable row level security;
alter table delivery_orders enable row level security; alter table order_status_history enable row level security;
alter table driver_applications enable row level security; alter table business_requests enable row level security; alter table admins enable row level security;

create or replace function is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from admins where user_id=auth.uid()) $$;

drop policy if exists zones_read on delivery_zones; create policy zones_read on delivery_zones for select using (active or is_admin());
drop policy if exists zones_admin on delivery_zones; create policy zones_admin on delivery_zones for all using (is_admin()) with check (is_admin());
drop policy if exists settings_read on pricing_settings; create policy settings_read on pricing_settings for select using (true);
drop policy if exists settings_admin on pricing_settings; create policy settings_admin on pricing_settings for all using (is_admin()) with check (is_admin());
drop policy if exists orders_admin on delivery_orders; create policy orders_admin on delivery_orders for all using (is_admin()) with check (is_admin());
drop policy if exists hist_admin on order_status_history; create policy hist_admin on order_status_history for all using (is_admin()) with check (is_admin());
drop policy if exists drivers_admin on driver_applications; create policy drivers_admin on driver_applications for all using (is_admin()) with check (is_admin());
drop policy if exists biz_admin on business_requests; create policy biz_admin on business_requests for all using (is_admin()) with check (is_admin());
-- Ajoutez votre compte admin : insert into admins values('<uuid de votre utilisateur Auth>');

revoke execute on function create_order(jsonb),apply_driver(jsonb),create_business_request(jsonb),quote(uuid,uuid),track_order(text,text),driver_status(text,text) from public;
grant execute on function create_order(jsonb),quote(uuid,uuid),track_order(text,text),apply_driver(jsonb),driver_status(text,text),create_business_request(jsonb) to anon,authenticated;
