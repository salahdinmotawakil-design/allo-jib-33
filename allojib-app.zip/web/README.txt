ALLO JIB — package complet (site + admin + espace livreur)

PAGES
  /                accueil          /order        commande
  /track           suivi            /pricing      tarifs
  /how  /business  /become-driver   /info
  /admin           tableau de bord (réservé aux comptes de la table admins ; aucun lien public, ouvrir l'adresse directement)
  /driver          espace livreur (connexion Google ou email, activation par l'admin)

MISE EN PLACE
1. Supabase (projet NEUF) : SQL Editor > coller supabase/all-in-one.sql > Run (une seule fois).
   (Projet déjà configuré : n'exécutez que les fichiers numérotés manquants.)
2. js/config.js : supabaseUrl + supabaseAnonKey (clé publishable). Jamais de clé secrète/service_role.
3. Compte admin : Authentication > Users > Add user (Auto Confirm), puis SQL :
     insert into admins (user_id) select id from auth.users where email='VOTRE-EMAIL';
4. Google (livreurs) : Authentication > Sign In / Providers > Google (Client ID + Secret),
   Authentication > URL Configuration : Site URL + Redirect URLs (/driver et /driver.html).
5. Cloudflare : déployer ce dossier (ou le ZIP).

À COMPLÉTER AVANT LANCEMENT
  - Numéro WhatsApp réel (js/config.js et table pricing_settings)
  - Coordonnées des zones (admin > المناطق) et hypothèses de prix (admin > الأثمنة)
  - Textes légaux (info.html : CGV, confidentialité, livraison) avec un juriste ; déclaration CNDP
NOTIFICATIONS : internes (cloche dans /admin et /driver, rafraîchies toutes les 30 s ; alertes navigateur seulement page ouverte).
  Pas de push téléphone ni d'envoi automatique WhatsApp/email : le bouton « 📲 أخبر الزبون » ouvre un message WhatsApp pré-rempli.
PHOTO DE LIVRAISON : bucket privé « proofs » (créé par 006_notifications_proofs.sql), visible uniquement par l'admin.
NON INCLUS : upload de documents livreur, GPS, compte client, carte, push téléphone.

DISPATCH AUTOMATIQUE (007_dispatch.sql)
  Nouvelle commande -> confirmée automatiquement -> offerte au livreur actif, Online et libre (celui libre depuis le plus longtemps).
  Le livreur voit zones/prix/distance, accepte ou refuse. Après acceptation : adresses + téléphone du client.
  Sans réponse après N minutes (admin > الأثمنة), l'offre passe à un autre livreur. Tous occupés : la commande attend,
  puis part au premier livreur qui termine une livraison. Désactivable (case dans admin > الأثمنة).
  Le dispatch se déclenche à chaque commande, connexion Online, fin de livraison et rafraîchissement livreur (15 s) : pas de cron.

DESIGN / APP
  Style « application » : barre de navigation fixe en bas sur mobile, installable sur l'écran d'accueil (manifest.webmanifest, driver.webmanifest + icônes).
  Formulaire de commande court : nom, téléphone, de/vers (zone + adresse), contenu du colis ; nom/téléphone du destinataire en option.

ACCUEIL : bienvenue/présentation -> FAQ -> formulaire de commande (même formulaire sur /order).
COMMANDE « À LA DEMANDE » : nom, téléphone, ce qu'on apporte, de où (zone + lieu), où (zone + adresse + bouton « utiliser ma position »).
  Contact au lieu d'enlèvement et destinataire différent : optionnels (par défaut le destinataire = le client).
GPS EN DIRECT (009_ondemand_gps.sql) : le livreur partage sa position seulement pendant une livraison active (supprimée ensuite) ;
  le client la voit sur /track (carte Leaflet + OpenStreetMap) avec référence + téléphone. Limite du web : le GPS s'arrête si l'écran est verrouillé
  ou l'app en arrière-plan (un vrai suivi en arrière-plan nécessitera l'application native).
