package ma.allojib.driver;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
